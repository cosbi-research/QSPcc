function [baseline_time, baseline_simulation, treatment_time, treatment_simulation] = perform_simulation(baseline_data_array, treatment_data_array)


%% extract simulation conditions
baseline_start                                      = baseline_data_array.simulation_settings(1);
baseline_interval                                   = baseline_data_array.simulation_settings(3);
baseline_end                                        = baseline_data_array.simulation_settings(2);

treatment_start                                     = treatment_data_array.simulation_settings(1);
treatment_interval                                  = treatment_data_array.simulation_settings(3);
treatment_end                                       = treatment_data_array.simulation_settings(2);

%% simulate baseline
disp('Performing baseline (disease development, no treatment) simulation ...')
% extract initial conditions
baseline_initial                                    = baseline_data_array.initial_conditions;

% extract tolerances
tol_relative                                        = baseline_data_array.simulation_settings(4);
tol_absolute                                        = baseline_data_array.simulation_settings(5);

% set options and simulate
ode_options_baseline                                = odeset('MaxOrder',5,'BDF','off','AbsTol',tol_absolute,'RelTol',tol_relative); 
[baseline_time, baseline_simulation]                = ode15s(@(t,x) assemble_differential_state_vector(t, x, baseline_data_array), baseline_start:baseline_interval:baseline_end, baseline_initial, ode_options_baseline); 

%% simulate treatment
disp('Performing treatment simulation ...')
% set initial conditions as the steady state conditions from baseline simulation
treatment_initial                                   = baseline_simulation(end,:);

% extract tolerances
tol_relative                                        = treatment_data_array.simulation_settings(4);
tol_absolute                                        = treatment_data_array.simulation_settings(5);

% set options and simulate; consider modifying Jacobian pattern
ode_options_treatment                               = odeset('MaxOrder',5,'BDF','off','AbsTol',tol_absolute,'RelTol',tol_relative); 
[treatment_time, treatment_simulation]              = ode15s(@(t,x) assemble_differential_state_vector(t, x, treatment_data_array), treatment_start:treatment_interval:treatment_end, treatment_initial, ode_options_treatment);
