function [phi_spleen, phi_lung] = cellular_level_submodel(x, u01_PK_molecular_cellular, u01_organ)

%% relevant state variable indices

SM_spleen_lyso              = 21; % lysosomal SM concentration in spleen
SM_lung_lyso                = 22; % lysosomal SM concentration in lung

SM_store_spleen             = 24; % extra-lysosomal SM concentration in spleen
SM_store_lung               = 25; % extra-lysosomal SM concentration in lung


%% assign input parameters

% SM critical value for macrophages (by organ) 
SM_crit_spleen          = u01_organ(1);
SM_crit_lung            = u01_organ(2);
    
% Estimated total lysosomal volume within a cell
V_lyso_total            = u01_PK_molecular_cellular(49);

%% calculation of phi
% calculated value, indicating degree of macrophage function ([0 1])

% spleen
phi_spleen              = 1 - ( (x(SM_spleen_lyso)*V_lyso_total + x(SM_store_spleen))^2 / ( (x(SM_spleen_lyso)*V_lyso_total + x(SM_store_spleen))^2 + SM_crit_spleen^2 ) );

% lung
phi_lung                = 1 - ( (x(SM_lung_lyso)*V_lyso_total + x(SM_store_lung))^2 / ( (x(SM_lung_lyso)*V_lyso_total + x(SM_store_lung))^2 + SM_crit_lung^2 ) );


