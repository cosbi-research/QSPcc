This folder contains sample MATLAB code to simulate the ASMD QSP model. 

- To run the model and generate plots of the plasma ceramide, plasma lysosphingomyelin, Hb-adjusted % predicted DLco, and spleen volume outputs,
run the script [script_run_ASMD_QSP_model.m]

- The overall file structure called within [script_run_ASMD_QSP_model.m] is as follows:

   i. [script_assemble_data_arrays.m] creates the MATLAB data arrays that contain the simulation settings and model input parameters. These
      data arrays have been pre-generated and saved as [data_arrays.mat]

   ii. [perform_simulation.m] accepts the data arrays as input and simulates the model by calling the MATLAB ode15s solver 
       with [assemble_differential_state_vector.m]

   iii. [assemble_differential_state_vector.m] computes the differential state vector at each step by calling the individual sub-model files 
	[PK_and_molecular_level_submodels.m], [cellular_level_submodel.m], and [organ_level_submodel.m]. 

	iii(a). [get_k_inf_rate.m] is a helper function called by [PK_and_molecular_level_submodels.m] for representing dosing

   iv. The script [create_plots.m] uses the output of [perform_simulation.m] in the workspace and plots four simulation outputs