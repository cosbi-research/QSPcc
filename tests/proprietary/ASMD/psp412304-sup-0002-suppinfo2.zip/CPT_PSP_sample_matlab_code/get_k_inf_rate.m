function k_inf = get_k_inf_rate(t, infusion_rates, dose_times, infusion_durations)
% function to calculate the current drug infusion rate (k_inf) with respect
% to dose time and infusion duration

k_inf = sum((t >= dose_times & t <= (dose_times + infusion_durations)).* infusion_rates);





