function dxdt = assemble_differential_state_vector(t, x, data_array)


%% extract drug status
drug_status                                         = data_array.r01_settings(1);

%% extract dose times, infusion durations, and infusion rates
dose_times                                          = data_array.r01_dose_times;
infusion_durations                                  = data_array.r01_infusion_duration;
infusion_rates                                      = data_array.r01_rate_schedule; 

%% extract parameters
u01_PK_molecular_cellular                           = data_array.u01_PK_molecular_cellular;
u01_organ                                           = data_array.u01_organ;

%% get diferential state variable vector: molecular-level

dxdt_molecular                                      = PK_and_molecular_level_submodels(t, x, drug_status, u01_PK_molecular_cellular, ...,
                                                        u01_organ, infusion_rates, dose_times, infusion_durations);
                                                
%% get macrophage status phi functions: cellular-level

[phi_spleen, phi_lung]                              = cellular_level_submodel(x, u01_PK_molecular_cellular, u01_organ);

%% get diferential state variable vector: organ-level

dxdt_organ                                          = organ_level_submodel(x, u01_organ, u01_PK_molecular_cellular, phi_spleen, phi_lung);
                                                
%% assemble total differential state variable vector
dxdt                                                = [dxdt_molecular(1:52); dxdt_organ(53:54)];


        

