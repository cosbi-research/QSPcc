% Script to construct data arrays describing simulation settings and model parameters
% for running the model in baseline (disease development, no treatment) and
% treatment (biweekly infusions of Olipudase alfa) modes

clear; clc
%% simulation_settings

    % baseline                                              
    t_start         = 0;                    % [hours] simulation start time
    t_final         = 175200;               % [hours] simulation end time
    t_interval      = 1;                    % [hours] output increment 
    tol_relative    = 1.0e-10;              % relative tolerance
    tol_absolute    = 1.0e-10;              % absolute tolerance
    
    baseline_simulation_settings = [t_start, t_final, t_interval, tol_relative, tol_absolute];
    clearvars -except  *_simulation_settings;
    
    % treatment    
    t_start         = 0;
    t_final         = 33600;
    t_interval      = 1; 
    tol_relative    = 1.0e-10;     
    tol_absolute    = 1.0e-10;    
    
    treatment_simulation_settings = [t_start, t_final, t_interval, tol_relative, tol_absolute];
    clearvars -except *_simulation_settings;
    
    % assign to structures
    baseline_data_array.simulation_settings    = baseline_simulation_settings;
    treatment_data_array.simulation_settings   = treatment_simulation_settings;

    clearvars -except baseline_data_array treatment_data_array 
    
%% initial_conditions 

    % baseline: zeros for all molecular state variables, 100 for Hb-adjusted % pred. DLco, 1 for spleen volume in MN    
    baseline_initial_conditions = [zeros(1,52) 100 1];
    
    % treatment: (1) zeros for all PBPK terms for all subjects, (2) approximation/placeholder for other state variables; 
    % these initial conditions should be substituted with the simulated baseline steady state valines
    treatment_initial_conditions = [zeros(1,19), 4.0e+05, 3.0e+06, 3.0e+06, 1.7e-06, 5.5e-05, 5.5e-05, 4.0e+04, 0, 7.0e+02, 0, 8.0e+02, 4.0e+04, 0, 1.0e+02, 0, 5.0e+03, 4.0e+04, 0, 1.0e+02, 0, 5.0e+03, 2.0e+01, 1.0e+01, 2.0e+01, 7.0e+01, 2.0e+01, 7.0e+01, 5.0e-06, 0, 8.0e-06, 8.0e-07, 8.0e-07, 8.0e-07, 6.0e+01, 1.0e+01];
      
    % assign to structures
    baseline_data_array.initial_conditions     = baseline_initial_conditions;
    treatment_data_array.initial_conditions    = treatment_initial_conditions; 
        
    clearvars -except baseline_data_array treatment_data_array 
   
%% r01_settings, indicating whether dosing is activated

    % baseline    
    treatment_status                = 0;        
    baseline_r01_settings           = [treatment_status];     %#ok<*NBRAK>
        
    % treatment    
    treatment_status                = 1;    
    treatment_r01_settings           = [treatment_status];
    
    % assign to structures
    baseline_data_array.r01_settings           = baseline_r01_settings;
    treatment_data_array.r01_settings          = treatment_r01_settings;   
    
    clearvars -except baseline_data_array treatment_data_array     
   
%% r01_dose_times: doses of Olipudase alfa administered Q2W

    dosing_interval                 = 336; % [hours] time between every biweekly dose
    dose_times                      = treatment_data_array.simulation_settings(1):dosing_interval:treatment_data_array.simulation_settings(2);
   
    % assign to structures
    baseline_data_array.r01_dose_times         = dose_times;
    treatment_data_array.r01_dose_times        = dose_times;
    
    clearvars -except baseline_data_array treatment_data_array dose_times
    
%% r01_dose_schedule: adult dose escalation schedule as described in Wasserstein et al. (2015)

    dose_escalation_schedule        = [0.1, 0.3, 0.3, 0.6, 1.0, 2.0, 3.0];
    n_doses_after_escalation        = numel(dose_times) - numel(dose_escalation_schedule);
    dose_schedule                   = [dose_escalation_schedule, 3.0 * ones(1, n_doses_after_escalation)];
    
    % assign to structures
    baseline_data_array.r01_dose_schedule      = dose_schedule;
    treatment_data_array.r01_dose_schedule     = dose_schedule;
    
    clearvars -except baseline_data_array treatment_data_array n_doses_after_escalation
    
%% r01_infusion_duration: typical infusion durations for each dose

    dose_escalation_inf_durations   = [0.6, 1.0, 1.0, 1.3, 1.7, 2.7, 3.7];
    infusion_durations              = [dose_escalation_inf_durations, 3.7 * ones(1, n_doses_after_escalation)];
   
    % assign to structures
    baseline_data_array.r01_infusion_duration  = infusion_durations;
    treatment_data_array.r01_infusion_duration = infusion_durations;    
    
%% r01_infusion_rate: calculate based on dose amount, weight, and infusion duration

    % arbitrary patient weight
    weight                          = 70; % [kg]
    
    % calculate infusion rate and convert from mg/hr to mol/hr ([mg/kg * kg * g/mg * mol/g * (1/hr)])
    MW_ASM                          = 78000; % [g/mol] molecular weight of rhASM 
    infusion_rates                  = ( (treatment_data_array.r01_dose_schedule * weight) * (1/1000) * (1/MW_ASM) ) ./ treatment_data_array.r01_infusion_duration; 
    
    % assign to structures
    baseline_data_array.r01_rate_schedule      = infusion_rates;
    treatment_data_array.r01_rate_schedule     = infusion_rates;
    
    clearvars -except baseline_data_array treatment_data_array      
    
%% u01_PK_molecular_cellular: parameters utilized primarily in the PK, molecular, and cellular sub-models

    kcat_ASM                        = 3.92E+04; 
    Km_ASM                          = 2.50E+01; 
    kcat_rhASM                      = 3.92E+04;    
    Km_rhASM                        = 2.50E+01;
    
                u01_PK_molecular_cellular(1) = kcat_ASM;
                u01_PK_molecular_cellular(2) = Km_ASM;
                u01_PK_molecular_cellular(3) = kcat_rhASM;
                u01_PK_molecular_cellular(4) = Km_rhASM;
                    
    k_clear_cer                     = 5.00E-01;
    k_int_liver                     = 6.00E+00;  
    k_int_spleen                    = 0.1*k_int_liver;  
    k_int_lung                      = 0.03*k_int_liver;  
    C_LNLF                          = 9.10E+00;
    
                u01_PK_molecular_cellular(5) = k_clear_cer;
                u01_PK_molecular_cellular(6) = k_int_liver;
                u01_PK_molecular_cellular(7) = k_int_spleen;
                u01_PK_molecular_cellular(8) = k_int_lung;   
                u01_PK_molecular_cellular(9) = C_LNLF;    

    V_V_liver                       = 1.83E-01;
    V_V_spleen                      = 2.70E-02;
    V_V_lung                        = 5.50E-02;
    V_V_SI                          = 6.20E-03;
    V_V_LI                          = 8.70E-03;
    V_V_pancreas                    = 5.70E-03;
    V_V_other                       = 1.43E+00;
    
                u01_PK_molecular_cellular(10) = V_V_liver;
                u01_PK_molecular_cellular(11) = V_V_spleen;
                u01_PK_molecular_cellular(12) = V_V_lung;
                u01_PK_molecular_cellular(13) = V_V_SI;   
                u01_PK_molecular_cellular(14) = V_V_LI;     
                u01_PK_molecular_cellular(15) = V_V_pancreas;   
                u01_PK_molecular_cellular(16) = V_V_other;                  

    V_IS_liver                      = 4.30E-01;
    V_IS_spleen                     = 4.40E-02; 
    V_IS_lung                       = 3.00E-01;
    V_IS_SI                         = 6.70E-02;
    V_IS_LI                         = 9.50E-02;
    V_IS_pancreas                   = 1.80E-02;
    V_IS_other                      = 1.04E+01;
    
                u01_PK_molecular_cellular(17) = V_IS_liver;
                u01_PK_molecular_cellular(18) = V_IS_spleen;
                u01_PK_molecular_cellular(19) = V_IS_lung;
                u01_PK_molecular_cellular(20) = V_IS_SI;   
                u01_PK_molecular_cellular(21) = V_IS_LI;     
                u01_PK_molecular_cellular(22) = V_IS_pancreas;   
                u01_PK_molecular_cellular(23) = V_IS_other;      

    PLQ_liver                       = 1.32E+01;
    PLQ_spleen                      = 6.34E+00;
    PLQ_lung                        = 1.82E+02;
    PLQ_SI                          = 1.24E+01;
    PLQ_LI                          = 1.29E+01;
    PLQ_pancreas                    = 3.06E+00;
    PLQ_other                       = 1.34E+02;

                u01_PK_molecular_cellular(24) = PLQ_liver;
                u01_PK_molecular_cellular(25) = PLQ_spleen;
                u01_PK_molecular_cellular(26) = PLQ_lung;
                u01_PK_molecular_cellular(27) = PLQ_SI;   
                u01_PK_molecular_cellular(28) = PLQ_LI;     
                u01_PK_molecular_cellular(29) = PLQ_pancreas;   
                u01_PK_molecular_cellular(30) = PLQ_other;   
                
    LF_liver                        = 2.40E-01;
    LF_spleen                       = 3.20E-02;
    LF_lung                         = 9.10E-01;
    LF_SI                           = 6.20E-02;
    LF_LI                           = 6.40E-02;
    LF_pancreas                     = 1.50E-02;
    LF_other                        = 6.70E-01;
    
                u01_PK_molecular_cellular(31) = LF_liver;
                u01_PK_molecular_cellular(32) = LF_spleen;
                u01_PK_molecular_cellular(33) = LF_lung;
                u01_PK_molecular_cellular(34) = LF_SI;   
                u01_PK_molecular_cellular(35) = LF_LI;     
                u01_PK_molecular_cellular(36) = LF_pancreas;   
                u01_PK_molecular_cellular(37) = LF_other;       

    V_plasma                        = 3.13E+00;
    V_lymph_node                    = 2.70E-01;

                u01_PK_molecular_cellular(38) = V_plasma;   
                u01_PK_molecular_cellular(39) = V_lymph_node;  
                
    AvN                             = 6.02E+23;
    V_lyso                          = 6.55E-17;
    lyso_total                      = 1.00E+03;
    V_cell_hepatocyte               = 2.00E-12;
    V_cell_macrophage               = 1.00E-11;
    cell_spleen                     = 1.00E+10;
    cell_liver                      = 1.90E+11;
    cell_lung                       = 3.00E+09;
    
                u01_PK_molecular_cellular(40) = AvN;
                u01_PK_molecular_cellular(41) = V_lyso;
                u01_PK_molecular_cellular(42) = lyso_total;
                u01_PK_molecular_cellular(43) = V_cell_hepatocyte;   
                u01_PK_molecular_cellular(44) = V_cell_macrophage;     
                u01_PK_molecular_cellular(45) = cell_spleen;   
                u01_PK_molecular_cellular(46) = cell_liver;     
                u01_PK_molecular_cellular(47) = cell_lung;  
    
    % calculated parameters 
    L_lymph_node                    = C_LNLF * PLQ_lung; 
    V_lyso_total                    = V_lyso * lyso_total;
    
    convert_volume_hepatocyte_to_plasma             = ((cell_liver*V_cell_hepatocyte/V_plasma)/10^6);
    convert_volume_spleen_macrophage_to_plasma      = ((cell_spleen*V_cell_macrophage/V_plasma)/10^6);
    convert_volume_lung_macrophage_to_plasma        = ((cell_lung*V_cell_macrophage/V_plasma)/10^6);
    
    convert_volume_lysosome_to_hepatocyte   = V_lyso_total/V_cell_hepatocyte;
    convert_volume_lysosome_to_macrophage   = V_lyso_total/V_cell_macrophage;
    
    conv_factor                     = (1.8E+04 / 24.0);
    conv_micro_units                = (1E+06);
    
                u01_PK_molecular_cellular(48) = L_lymph_node;
                u01_PK_molecular_cellular(49) = V_lyso_total;
                u01_PK_molecular_cellular(50) = convert_volume_hepatocyte_to_plasma;
                u01_PK_molecular_cellular(51) = convert_volume_spleen_macrophage_to_plasma;   
                u01_PK_molecular_cellular(52) = convert_volume_lung_macrophage_to_plasma;     
                u01_PK_molecular_cellular(53) = convert_volume_lysosome_to_hepatocyte;   
                u01_PK_molecular_cellular(54) = convert_volume_lysosome_to_macrophage;     
                u01_PK_molecular_cellular(55) = conv_factor; 
                u01_PK_molecular_cellular(56) = conv_micro_units; 
                
                            
    ASM_total                       = 3.33E+03;
    acylSMase_num                   = 2.00E+02;
    kcat_acylSMase                  = 3.60E+03;
    Km_acyl                         = 2.50E+01;

    k_rhASM_loss                    = 1.00E-01;

    SM_max_hepatocyte               = 5.00E-06;
    SM_max_macrophage               = 9.56E-05;   
    
                u01_PK_molecular_cellular(57) = ASM_total;
                u01_PK_molecular_cellular(58) = acylSMase_num;
                u01_PK_molecular_cellular(59) = kcat_acylSMase;
                u01_PK_molecular_cellular(60) = Km_acyl;   
                u01_PK_molecular_cellular(61) = k_rhASM_loss;     
                u01_PK_molecular_cellular(62) = SM_max_hepatocyte;   
                u01_PK_molecular_cellular(63) = SM_max_macrophage;     
    
   
    % calculated parameters
    E0                              = ((( ASM_total / AvN) / V_lyso_total) * 10e5);
    acylSMase                       = (((acylSMase_num / AvN) / V_lyso_total) * 10e5);
    
                u01_PK_molecular_cellular(64) = E0;   
                u01_PK_molecular_cellular(65) = acylSMase; 
                      
    
    SM_prod_liver                   = 2.00E+00;
    SM_prod_spleen                  = 2*SM_prod_liver;
    SM_prod_lung                    = 2*SM_prod_liver;
    
    ASM_prct_residual               = 1.50E+01 / 100;
    kdeg_plasma                     = 1.00E-01;
    
                u01_PK_molecular_cellular(66) = SM_prod_liver;
                u01_PK_molecular_cellular(67) = SM_prod_spleen;
                u01_PK_molecular_cellular(68) = SM_prod_lung;
                u01_PK_molecular_cellular(69) = ASM_prct_residual;   
                u01_PK_molecular_cellular(70) = kdeg_plasma;    
                
    sigma_V_liver                   = 9.00E-01;
    sigma_V_spleen                  = 9.90E-01;
    sigma_V_lung                    = 9.90E-01;
    sigma_V_SI                      = 9.00E-01;
    sigma_V_LI                      = 9.00E-01;
    sigma_V_pancreas                = 9.00E-01;
    sigma_V_other                   = 5.00E-01;
    
                u01_PK_molecular_cellular(71) = sigma_V_liver;
                u01_PK_molecular_cellular(72) = sigma_V_spleen;
                u01_PK_molecular_cellular(73) = sigma_V_lung;
                u01_PK_molecular_cellular(74) = sigma_V_SI;   
                u01_PK_molecular_cellular(75) = sigma_V_LI;
                u01_PK_molecular_cellular(76) = sigma_V_pancreas;   
                u01_PK_molecular_cellular(77) = sigma_V_other;     
                
    sigma_IS_liver                  = 1.00E-03;
    sigma_IS_spleen                 = 9.00E-01;
    sigma_IS_lung                   = 1.00E-02;
    sigma_IS_SI                     = 9.00E-01;
    sigma_IS_LI                     = 9.00E-01; 
    sigma_IS_pancreas               = 9.00E-01;
    sigma_IS_other                  = 1.00E-03;
    
                u01_PK_molecular_cellular(78) = sigma_IS_liver;
                u01_PK_molecular_cellular(79) = sigma_IS_spleen;
                u01_PK_molecular_cellular(80) = sigma_IS_lung;
                u01_PK_molecular_cellular(81) = sigma_IS_SI;   
                u01_PK_molecular_cellular(82) = sigma_IS_LI;
                u01_PK_molecular_cellular(83) = sigma_IS_pancreas;   
                u01_PK_molecular_cellular(84) = sigma_IS_other;     
    
    kcat_endo1                      = 6.00E-05;
    kcat_endo2                      = 2.00E-05;

    k_cer_tlyso                     = 5.00E-02;
    k_lysoSM_tlyso                  = 1.00E+00;

    k_exchange_liver                = 7.50E-04; 
    k_exchange_spleen               = 7.50E-04;
    k_exchange_lung                 = 7.50E-04;
    
                u01_PK_molecular_cellular(85) = kcat_endo1;
                u01_PK_molecular_cellular(86) = kcat_endo2;
                u01_PK_molecular_cellular(87) = k_cer_tlyso;
                u01_PK_molecular_cellular(88) = k_lysoSM_tlyso;   
                u01_PK_molecular_cellular(89) = k_exchange_liver;
                u01_PK_molecular_cellular(90) = k_exchange_spleen;   
                u01_PK_molecular_cellular(91) = k_exchange_lung;       


    k_cer_metab_liver               = 0;
    k_cer_metab_spleen              = 5.00E-02;
    k_cer_metab_lung                = 5.00E-02;
    
    k_cer_endo_metab_liver          = 0;           
    k_cer_endo_metab_spleen         = 5.00E-02;    
    k_cer_endo_metab_lung           = 5.00E-02;    
    
                u01_PK_molecular_cellular(92) = k_cer_metab_liver;
                u01_PK_molecular_cellular(93) = k_cer_metab_spleen;
                u01_PK_molecular_cellular(94) = k_cer_metab_lung;
                u01_PK_molecular_cellular(95) = k_cer_endo_metab_liver;   
                u01_PK_molecular_cellular(96) = k_cer_endo_metab_spleen;
                u01_PK_molecular_cellular(97) = k_cer_endo_metab_lung;   
  
    k_lysoSM_metab_liver            = 1.50E+00; 
    k_lysoSM_metab_spleen           = 1.50E+00; 
    k_lysoSM_metab_lung             = 1.50E+00; 

    k_exo_cer_liver                 = 1.00E-02 ;
    k_exo_cer_spleen                = 0;         
    k_exo_cer_lung                  = 0;         
    
    k_exo_cer_endo_liver            = 1.00E-02;  
    k_exo_cer_endo_spleen           = 0; 
    k_exo_cer_endo_lung             = 0; 
    
                u01_PK_molecular_cellular(98) = k_lysoSM_metab_liver;
                u01_PK_molecular_cellular(99) = k_lysoSM_metab_spleen;
                u01_PK_molecular_cellular(100) = k_lysoSM_metab_lung;
                u01_PK_molecular_cellular(101) = k_exo_cer_liver;   
                u01_PK_molecular_cellular(102) = k_exo_cer_spleen;
                u01_PK_molecular_cellular(103) = k_exo_cer_lung;   
                u01_PK_molecular_cellular(104) = k_exo_cer_endo_liver;   
                u01_PK_molecular_cellular(105) = k_exo_cer_endo_spleen;
                u01_PK_molecular_cellular(106) = k_exo_cer_endo_lung;   
   
    k_exo_lysoSM_liver              = 1.00E-02;    
    k_exo_lysoSM_spleen             = 2.00E-02;    
    k_exo_lysoSM_lung               = 2.00E-02;  
    k_clear_lysoSM                  = 5.00E-02;    
    
                u01_PK_molecular_cellular(107) = k_exo_lysoSM_liver;   
                u01_PK_molecular_cellular(108) = k_exo_lysoSM_spleen;   
                u01_PK_molecular_cellular(109) = k_exo_lysoSM_lung;
                u01_PK_molecular_cellular(110) = k_clear_lysoSM;
    
    phi_lysoSM_implement            = 1.00E+00;       
    phi_lysoSM_exponent             = 1.50E+00;     
    phi_lysoSM_spleen_lung_crit_adj = 1.00E-02;
    phi_lysoSM_liver_crit_adj       = 1.00E+00;    
    
                u01_PK_molecular_cellular(111) = phi_lysoSM_implement;   
                u01_PK_molecular_cellular(112) = phi_lysoSM_exponent;   
                u01_PK_molecular_cellular(113) = phi_lysoSM_spleen_lung_crit_adj;
                u01_PK_molecular_cellular(114) = phi_lysoSM_liver_crit_adj;
   
    % assign to structures
    baseline_data_array.u01_PK_molecular_cellular  = u01_PK_molecular_cellular;
    treatment_data_array.u01_PK_molecular_cellular = u01_PK_molecular_cellular;
    
    clearvars -except baseline_data_array treatment_data_array 
 
%% u01_organ        

    % phi-function related - also used in molecular-level model                 
    SM_crit_spleen                  = 4.00E-05;
    SM_crit_lung                    = 4.00E-05;    
    SM_crit_liver                   = 4.00E-05; 
    SM_crit_phi_balance             = 2.00E+06;                      
      
                u01_organ(1)            = SM_crit_spleen;   
                u01_organ(2)            = SM_crit_lung;   
                u01_organ(3)            = SM_crit_liver;
                u01_organ(4)            = SM_crit_phi_balance;    
                
    % lung
    beta_npd                        = 1.00E-05;
    DLco_adj                        = 7.00E+01;
    beta_repair                     = 1.00E-05;
    
                u01_organ(5)            = beta_npd;   
                u01_organ(6)            = DLco_adj;   
                u01_organ(7)            = beta_repair;
 
    % spleen    
    R_npd                           = 5.00E-04;
    R_repair                        = 1.00E-05;
    R_repair_fast                   = 5.00E-03;
    
    spleen_max_size                 = 2.60E+01;
    spleen_min_size                 = 1;    
    
                u01_organ(8)            = R_npd;   
                u01_organ(9)            = R_repair;   
                u01_organ(10)           = R_repair_fast;
                u01_organ(11)           = spleen_max_size;   
                u01_organ(12)           = spleen_min_size;                
                
    % assign to structures
    baseline_data_array.u01_organ  = u01_organ;
    treatment_data_array.u01_organ = u01_organ;
    
    clearvars -except baseline_data_array treatment_data_array 
    
%% set the fields to the appropriate order:

baseline_data_array = orderfields(baseline_data_array, {...
'simulation_settings',...
'initial_conditions',...
'r01_settings', ...
'r01_dose_times', ...
'r01_dose_schedule', ...
'r01_rate_schedule', ...
'r01_infusion_duration', ...
'u01_PK_molecular_cellular', ...
'u01_organ' ...
});

treatment_data_array = orderfields(treatment_data_array, {...
'simulation_settings',...
'initial_conditions',...
'r01_settings', ...
'r01_dose_times', ...
'r01_dose_schedule', ...
'r01_rate_schedule', ...
'r01_infusion_duration', ...
'u01_PK_molecular_cellular', ...
'u01_organ' ...
});

%% save
save('data_arrays.mat', 'baseline_data_array', 'treatment_data_array')
