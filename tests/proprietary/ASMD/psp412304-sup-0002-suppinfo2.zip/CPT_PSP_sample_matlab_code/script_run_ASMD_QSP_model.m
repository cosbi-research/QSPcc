% Sample script to run the ASMD QSP model in MATLAB and generate plots of key outputs

clear; clc; close all
%% Step 1: Load data arrays describing baseline (disease development, no drug) and treatment (adminitration of Olipudase alfa) 
% These data arrays contain simulation settings and model parameters; see [script_assemble_data_arrays.m] for more details
load('data_arrays.mat')

%% Step 2: Simulate model
[baseline_time, baseline_simulation, treatment_time, treatment_simulation]  = perform_simulation(baseline_data_array, treatment_data_array);

%% Step 3: Plot predicted plasma ceramide, plasma lysosphingomyelin, Hb-adjusted % pred. DLco, and spleen volume outputs
disp('Plotting simulaton output ...')
create_plots;


