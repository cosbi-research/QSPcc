function dxdt = organ_level_submodel(x, u01_organ, u01_PK_molecular_cellular, phi_spleen, phi_lung)

%% organ-level state space indices

dlco                        = 53;
spleen_volume               = 54;

dxdt                        = zeros(54,1);

%% relevant molecular-level state variable indices

SM_spleen_lyso              = 21; % lysosomal SM concentration in spleen
SM_lung_lyso                = 22; % lysosomal SM concentration in lung

SM_store_spleen             = 24; % extra-lysosomal SM concentration in spleen
SM_store_lung               = 25; % extra-lysosomal SM concentration in lung

%% unpack parameters

SM_crit_phi_balance         = u01_organ(4);
                                        
% lung-related
beta_npd                    = u01_organ(5); 
DLco_adj                    = u01_organ(6); 
beta_repair                 = u01_organ(7); 

% spleen-related
R_npd                       = u01_organ(8);  
R_repair                    = u01_organ(9);
R_repair_fast               = u01_organ(10);
spleen_max_size             = u01_organ(11);
spleen_min_size             = u01_organ(12);
    
% from molecular-level:
SM_max_macrophage           = u01_PK_molecular_cellular(63); 
V_cell_macrophage           = u01_PK_molecular_cellular(44); 
V_lyso_total                = u01_PK_molecular_cellular(49);


%% dlco

v100                        = -beta_npd*(1-phi_lung)*(x(dlco)-(100-DLco_adj*(x(SM_lung_lyso)*V_lyso_total + x(SM_store_lung))/SM_max_macrophage));
v101                        = beta_repair*phi_lung*(100-x(dlco));
dxdt(dlco)                  = v100 + v101;

%% spleen

% define phi_balance
phi_balance_numerator       = ( (x(SM_store_spleen) / V_cell_macrophage) - x(SM_spleen_lyso) )^2 ;
phi_balance_denominator     = ( (x(SM_store_spleen) / V_cell_macrophage) - x(SM_spleen_lyso) )^2 + SM_crit_phi_balance^2;
phi_balance                 = phi_balance_numerator / phi_balance_denominator;   
  
v102                        = R_npd * (1-phi_spleen) * (spleen_max_size - x(spleen_volume));
v103                        = R_repair * phi_spleen * (x(spleen_volume) - spleen_min_size);
v104                        = R_repair_fast * phi_balance;
dxdt(spleen_volume)         = v102 - v103 - v104;   



    


