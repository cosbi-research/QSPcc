function dydt = Gaucher_Disease_Type1_QSP(time, y,parameters, calculated_parameters)
%% state variable indexing

n_state_variables                               = 52;



%% GSL dynamics in the liver

    Liver_GSL_v_storage                         =  parameters(57) - parameters(59) - parameters(58) ; 

    Liver_GSL_r_efflux_coefficient              = calculated_parameters(69)*calculated_parameters(68)/parameters(52);
    Liver_GSL_r_efflux_Cer                      = Liver_GSL_r_efflux_coefficient*y(15) ; 
    Liver_GSL_r_efflux_GL1                      = Liver_GSL_r_efflux_coefficient*y(16) ; 
    Liver_GSL_r_efflux_GL2                      = Liver_GSL_r_efflux_coefficient*y(17) ; 
    Liver_GSL_r_efflux_GL3                      = Liver_GSL_r_efflux_coefficient*y(18) ; 
    Liver_GSL_r_efflux_GM3                      = Liver_GSL_r_efflux_coefficient*y(19) ; 
  
    Liver_GSL_c_Cer_VLDL                        = y(22); 
    Liver_GSL_c_GL1_VLDL                        = y(25); 
    Liver_GSL_c_GL2_VLDL                        = y(28); 
    Liver_GSL_c_GL3_VLDL                        = y(31); 
    Liver_GSL_c_GM3_VLDL                        = y(34); 

    Liver_GSL_c_Cer_LDL                         = y(21); 
    Liver_GSL_c_GL1_LDL                         = y(24); 
    Liver_GSL_c_GL2_LDL                         = y(27); 
    Liver_GSL_c_GL3_LDL                         = y(30); 
    Liver_GSL_c_GM3_LDL                         = y(33);

    Liver_GSL_c_Cer_HDL                         = y(20); 
    Liver_GSL_c_GL1_HDL                         = y(23); 
    Liver_GSL_c_GL2_HDL                         = y(26); 
    Liver_GSL_c_GL3_HDL                         = y(29); 
    Liver_GSL_c_GM3_HDL                         = y(32); 


    VLDL_factor                                 = calculated_parameters(65)*parameters(57);
    LDL_factor                                  = calculated_parameters(66)*parameters(57); 
    HDL_factor                                  = calculated_parameters(67)*parameters(57);

    Liver_GSL_r_uptake_Cer_VLDL                 = VLDL_factor*Liver_GSL_c_Cer_VLDL ;
    Liver_GSL_r_uptake_GL1_VLDL                 = VLDL_factor*Liver_GSL_c_GL1_VLDL ;
    Liver_GSL_r_uptake_GL2_VLDL                 = VLDL_factor*Liver_GSL_c_GL2_VLDL ;
    Liver_GSL_r_uptake_GL3_VLDL                 = VLDL_factor*Liver_GSL_c_GL3_VLDL ;
    Liver_GSL_r_uptake_GM3_VLDL                 = VLDL_factor*Liver_GSL_c_GM3_VLDL ;

    Liver_GSL_r_uptake_Cer_LDL                  = LDL_factor*Liver_GSL_c_Cer_LDL ;
    Liver_GSL_r_uptake_GL1_LDL                  = LDL_factor*Liver_GSL_c_GL1_LDL ;
    Liver_GSL_r_uptake_GL2_LDL                  = LDL_factor*Liver_GSL_c_GL2_LDL ;
    Liver_GSL_r_uptake_GL3_LDL                  = LDL_factor*Liver_GSL_c_GL3_LDL ;
    Liver_GSL_r_uptake_GM3_LDL                  = LDL_factor*Liver_GSL_c_GM3_LDL ;        

    Liver_GSL_r_uptake_Cer_HDL                  = HDL_factor*Liver_GSL_c_Cer_HDL ;
    Liver_GSL_r_uptake_GL1_HDL                  = HDL_factor*Liver_GSL_c_GL1_HDL ;
    Liver_GSL_r_uptake_GL2_HDL                  = HDL_factor*Liver_GSL_c_GL2_HDL ;
    Liver_GSL_r_uptake_GL3_HDL                  = HDL_factor*Liver_GSL_c_GL3_HDL ;
    Liver_GSL_r_uptake_GM3_HDL                  = HDL_factor*Liver_GSL_c_GM3_HDL ;

    Liver_GSL_r_prod_Cer                        = parameters(34)*parameters(38)*parameters(33)/(parameters(33)+y(5))*parameters(59) ; 

    Liver_GSL_r_Cer_to_other                    = parameters(35)*max(1e-9,y(5))^parameters(37)/(parameters(36)^parameters(37)+max(1e-9,y(5))^parameters(37))*parameters(59) ;
    

    Liver_GSL_r_rxn_GL1S                        = calculated_parameters(33)*calculated_parameters(17)*Liver_GSL_c_e_GL1S*y(5)/(calculated_parameters(1)+y(5))*parameters(59);
    Liver_GSL_r_rxn_GL2S                        = calculated_parameters(35)*calculated_parameters(19)*Liver_GSL_c_e_GL2S*y(6)/(calculated_parameters(3)+y(6))*parameters(59);
    Liver_GSL_r_rxn_GM3S                        = calculated_parameters(39)*calculated_parameters(23)*Liver_GSL_c_e_GM3S*y(7)/(calculated_parameters(7)+y(7))*parameters(59);
    Liver_GSL_r_rxn_GL3S                        = calculated_parameters(37)*calculated_parameters(21)*Liver_GSL_c_e_GL3S*y(7)/(calculated_parameters(5)+y(7))*parameters(59);

    Liver_GSL_r_rxn_GL1D                        = calculated_parameters(34)*calculated_parameters(18)*Liver_GSL_c_e_GL1D*y(11)/(calculated_parameters(2)+y(11))*parameters(58);
    Liver_GSL_r_rxn_GL2D                        = calculated_parameters(36)*calculated_parameters(20)*Liver_GSL_c_e_GL2D*y(12)/(calculated_parameters(4)+y(12))*parameters(58);
    Liver_GSL_r_rxn_GM3D                        = calculated_parameters(40)*calculated_parameters(24)*Liver_GSL_c_e_GM3D*y(14)/(calculated_parameters(8)+y(14))*parameters(58);
    Liver_GSL_r_rxn_GL3D                        = calculated_parameters(38)*calculated_parameters(22)*Liver_GSL_c_e_GL3D*y(13)/(calculated_parameters(6)+y(13))*parameters(58);


    Liver_GSL_r_rxn_golgi_Cer                   = -Liver_GSL_r_rxn_GL1S + Liver_GSL_r_prod_Cer - Liver_GSL_r_Cer_to_other ; 
    Liver_GSL_r_rxn_golgi_GL1                   = Liver_GSL_r_rxn_GL1S - Liver_GSL_r_rxn_GL2S ;
    Liver_GSL_r_rxn_golgi_GL2                   = Liver_GSL_r_rxn_GL2S - Liver_GSL_r_rxn_GM3S - Liver_GSL_r_rxn_GL3S;
    Liver_GSL_r_rxn_golgi_GM3                   = Liver_GSL_r_rxn_GM3S ;
    Liver_GSL_r_rxn_golgi_GL3                   = Liver_GSL_r_rxn_GL3S ;

    Liver_GSL_r_rxn_lyso_Cer                    = Liver_GSL_r_rxn_GL1D ;
    Liver_GSL_r_rxn_lyso_GL1                    = -Liver_GSL_r_rxn_GL1D + Liver_GSL_r_rxn_GL2D ;
    Liver_GSL_r_rxn_lyso_GL2                    = -Liver_GSL_r_rxn_GL2D + Liver_GSL_r_rxn_GM3D + Liver_GSL_r_rxn_GL3D ;
    Liver_GSL_r_rxn_lyso_GM3                    = -Liver_GSL_r_rxn_GM3D ;
    Liver_GSL_r_rxn_lyso_GL3                    = -Liver_GSL_r_rxn_GL3D ;
  


%% GSL dynamics in other tissues

    Tissue_GSL_v_storage                        =  parameters(61) - parameters(63) - parameters(62) ;  

    TisGSL_r_efflux_coefficient                 = calculated_parameters(74)*calculated_parameters(73)/parameters(53);
    Tissue_GSL_r_efflux_Cer                     = TisGSL_r_efflux_coefficient*y(48) ; 
    Tissue_GSL_r_efflux_GL1                     = TisGSL_r_efflux_coefficient*y(49) ; 
    Tissue_GSL_r_efflux_GL2                     = TisGSL_r_efflux_coefficient*y(50) ; 
    Tissue_GSL_r_efflux_GL3                     = TisGSL_r_efflux_coefficient*y(51) ; 
    Tissue_GSL_r_efflux_GM3                     = TisGSL_r_efflux_coefficient*y(52) ; 
  
    Tissue_GSL_c_Cer_VLDL                       = y(22); 
    Tissue_GSL_c_GL1_VLDL                       = y(25); 
    Tissue_GSL_c_GL2_VLDL                       = y(28); 
    Tissue_GSL_c_GL3_VLDL                       = y(31); 
    Tissue_GSL_c_GM3_VLDL                       = y(34); 

    Tissue_GSL_c_Cer_LDL                        = y(21); 
    Tissue_GSL_c_GL1_LDL                        = y(24); 
    Tissue_GSL_c_GL2_LDL                        = y(27); 
    Tissue_GSL_c_GL3_LDL                        = y(30); 
    Tissue_GSL_c_GM3_LDL                        = y(33); 

    Tissue_GSL_c_Cer_HDL                        = y(20); 
    Tissue_GSL_c_GL1_HDL                        = y(23); 
    Tissue_GSL_c_GL2_HDL                        = y(26); 
    Tissue_GSL_c_GL3_HDL                        = y(29); 
    Tissue_GSL_c_GM3_HDL                        = y(32);     
    

    VLDL_tissue_factor                          = calculated_parameters(70)*parameters(61);
    LDL_tissue_factor                           = calculated_parameters(71)*parameters(61); 
    HDL_tissue_factor                           = calculated_parameters(72)*parameters(61);

    Tissue_GSL_r_uptake_Cer_VLDL                = VLDL_tissue_factor*Tissue_GSL_c_Cer_VLDL ;
    Tissue_GSL_r_uptake_GL1_VLDL                = VLDL_tissue_factor*Tissue_GSL_c_GL1_VLDL ;
    Tissue_GSL_r_uptake_GL2_VLDL                = VLDL_tissue_factor*Tissue_GSL_c_GL2_VLDL ;
    Tissue_GSL_r_uptake_GL3_VLDL                = VLDL_tissue_factor*Tissue_GSL_c_GL3_VLDL ;
    Tissue_GSL_r_uptake_GM3_VLDL                = VLDL_tissue_factor*Tissue_GSL_c_GM3_VLDL ;

    Tissue_GSL_r_uptake_Cer_LDL                 = LDL_tissue_factor*Tissue_GSL_c_Cer_LDL ;
    Tissue_GSL_r_uptake_GL1_LDL                 = LDL_tissue_factor*Tissue_GSL_c_GL1_LDL ;
    Tissue_GSL_r_uptake_GL2_LDL                 = LDL_tissue_factor*Tissue_GSL_c_GL2_LDL ;
    Tissue_GSL_r_uptake_GL3_LDL                 = LDL_tissue_factor*Tissue_GSL_c_GL3_LDL ;
    Tissue_GSL_r_uptake_GM3_LDL                 = LDL_tissue_factor*Tissue_GSL_c_GM3_LDL ;        

    Tissue_GSL_r_uptake_Cer_HDL                 = HDL_tissue_factor*Tissue_GSL_c_Cer_HDL ;
    Tissue_GSL_r_uptake_GL1_HDL                 = HDL_tissue_factor*Tissue_GSL_c_GL1_HDL ;
    Tissue_GSL_r_uptake_GL2_HDL                 = HDL_tissue_factor*Tissue_GSL_c_GL2_HDL ;
    Tissue_GSL_r_uptake_GL3_HDL                 = HDL_tissue_factor*Tissue_GSL_c_GL3_HDL ;
    Tissue_GSL_r_uptake_GM3_HDL                 = HDL_tissue_factor*Tissue_GSL_c_GM3_HDL ;
    

    Tissue_GSL_r_prod_Cer                       = parameters(40)*parameters(44)*parameters(39)/(parameters(39)+y(38))*parameters(63) ;

    Tissue_GSL_r_Cer_to_other                   = parameters(41)*max(1e-9,y(38))^parameters(43)/(parameters(42)^parameters(43)+max(1e-9,y(38))^parameters(43))*parameters(63) ;
  
    Tissue_GSL_c_e_coefficient_syn              = parameters(51)*(parameters(61)/parameters(64))/parameters(1)/parameters(63)*1E6;
    Tissue_GSL_c_e_coefficient_deg              = parameters(51)*(parameters(61)/parameters(64))/parameters(1)/parameters(62)*1E6;
    
    Tissue_GSL_c_e_GL1S                         = Tissue_GSL_adj_GL1S*  calculated_parameters(57)*Tissue_GSL_c_e_coefficient_syn;
    Tissue_GSL_c_e_GL2S                         =                       calculated_parameters(59)*Tissue_GSL_c_e_coefficient_syn;
    Tissue_GSL_c_e_GL3S                         =                       calculated_parameters(61)*Tissue_GSL_c_e_coefficient_syn;
    Tissue_GSL_c_e_GM3S                         =                       calculated_parameters(63)*Tissue_GSL_c_e_coefficient_syn;

    Tissue_GSL_c_e_GL1D                         = parameters(46)*  calculated_parameters(58)*Tissue_GSL_c_e_coefficient_deg;
    Tissue_GSL_c_e_GL2D                         =                       calculated_parameters(60)*Tissue_GSL_c_e_coefficient_deg;
    Tissue_GSL_c_e_GL3D                         = parameters(49)*  calculated_parameters(62)*Tissue_GSL_c_e_coefficient_deg;
    Tissue_GSL_c_e_GM3D                         =                       calculated_parameters(64)*Tissue_GSL_c_e_coefficient_deg;

    Tissue_GSL_r_rxn_GL1S                       = calculated_parameters(41)*calculated_parameters(25)*Tissue_GSL_c_e_GL1S*y(38)/(calculated_parameters(9)+y(38))*parameters(63);
    Tissue_GSL_r_rxn_GL2S                       = calculated_parameters(43)*calculated_parameters(27)*Tissue_GSL_c_e_GL2S*y(39)/(calculated_parameters(11)+y(39))*parameters(63);
    Tissue_GSL_r_rxn_GM3S                       = calculated_parameters(47)*calculated_parameters(31)*Tissue_GSL_c_e_GM3S*y(40)/(calculated_parameters(15)+y(40))*parameters(63);
    Tissue_GSL_r_rxn_GL3S                       = calculated_parameters(45)*calculated_parameters(29)*Tissue_GSL_c_e_GL3S*y(40)/(calculated_parameters(13)+y(40))*parameters(63);

    Tissue_GSL_r_rxn_GL1D                       = calculated_parameters(42)*calculated_parameters(26)*Tissue_GSL_c_e_GL1D*y(44)/(calculated_parameters(10)+y(44))*parameters(62);
    Tissue_GSL_r_rxn_GL2D                       = calculated_parameters(44)*calculated_parameters(28)*Tissue_GSL_c_e_GL2D*y(45)/(calculated_parameters(12)+y(45))*parameters(62);
    Tissue_GSL_r_rxn_GM3D                       = calculated_parameters(48)*calculated_parameters(32)*Tissue_GSL_c_e_GM3D*y(47)/(calculated_parameters(16)+y(47))*parameters(62);
    Tissue_GSL_r_rxn_GL3D                       = calculated_parameters(46)*calculated_parameters(30)*Tissue_GSL_c_e_GL3D*y(46)/(calculated_parameters(14)+y(46))*parameters(62);

    Tissue_GSL_r_rxn_golgi_Cer                  = -Tissue_GSL_r_rxn_GL1S + Tissue_GSL_r_prod_Cer - Tissue_GSL_r_Cer_to_other ; 
    Tissue_GSL_r_rxn_golgi_GL1                  = Tissue_GSL_r_rxn_GL1S - Tissue_GSL_r_rxn_GL2S ;
    Tissue_GSL_r_rxn_golgi_GL2                  = Tissue_GSL_r_rxn_GL2S - Tissue_GSL_r_rxn_GM3S - Tissue_GSL_r_rxn_GL3S;
    Tissue_GSL_r_rxn_golgi_GM3                  = Tissue_GSL_r_rxn_GM3S ;
    Tissue_GSL_r_rxn_golgi_GL3                  = Tissue_GSL_r_rxn_GL3S ;

    Tissue_GSL_r_rxn_lyso_Cer                   = Tissue_GSL_r_rxn_GL1D ;
    Tissue_GSL_r_rxn_lyso_GL1                   = -Tissue_GSL_r_rxn_GL1D + Tissue_GSL_r_rxn_GL2D ;
    Tissue_GSL_r_rxn_lyso_GL2                   = -Tissue_GSL_r_rxn_GL2D + Tissue_GSL_r_rxn_GM3D + Tissue_GSL_r_rxn_GL3D ;
    Tissue_GSL_r_rxn_lyso_GM3                   = -Tissue_GSL_r_rxn_GM3D ;
    Tissue_GSL_r_rxn_lyso_GL3                   = -Tissue_GSL_r_rxn_GL3D ;


%% Lipoprotein transport 

    LP_r_prod_VLDL                              = parameters(10)*parameters(18)*parameters(65) ; 
    LP_r_up_liver_VLDL                          = parameters(13)*parameters(21)*y(37)*parameters(65) ; 
    LP_k_up_tissue_VLDL                         = parameters(13)*parameters(21)/(parameters(16)*parameters(24)) ;
    LP_r_up_tissue_VLDL                         = LP_k_up_tissue_VLDL*y(37)*parameters(65) ; 
     
    LP_r_conv_VLDL_LDL                          = parameters(12)*parameters(20)*y(37)*parameters(65) ; 
    LP_r_up_liver_LDL                           = parameters(14)*parameters(22)*y(36)*parameters(65) ; 
    LP_k_up_tissue_LDL                          = parameters(14)*parameters(22)/(parameters(16)*parameters(24)) ; 
    LP_r_up_tissue_LDL                          = LP_k_up_tissue_LDL*y(36)*parameters(65) ; 

    LP_r_prod_HDL                               = parameters(11)*parameters(19)*parameters(65) ; 
    LP_r_up_liver_HDL                           = parameters(15)*parameters(23)*y(35)*parameters(65) ; 


    LP_fpack_GSL_VLDL_Cer                       = parameters(54)*y(15)/parameters(52) ;
    LP_fpack_GSL_HDL_Cer                        = parameters(55)*y(48)/calculated_parameters(75) ;

    LP_fpack_GSL_VLDL_GL1                       = parameters(54)*y(16)/parameters(52) ;
    LP_fpack_GSL_HDL_GL1                        = parameters(55)*y(49)/calculated_parameters(75) ;

    LP_fpack_GSL_VLDL_GL2                       = parameters(54)*y(17)/parameters(52) ;
    LP_fpack_GSL_HDL_GL2                        = parameters(55)*y(50)/calculated_parameters(75) ;

    LP_fpack_GSL_VLDL_GL3                       = parameters(54)*y(18)/parameters(52) ;
    LP_fpack_GSL_HDL_GL3                        = parameters(55)*y(51)/calculated_parameters(75) ;

    LP_fpack_GSL_VLDL_GM3                       = parameters(54)*y(19)/parameters(52) ;
    LP_fpack_GSL_HDL_GM3                        = parameters(55)*y(52)/calculated_parameters(75) ;

    LP_r_prod_GSL_liver_Cer                     = LP_r_prod_VLDL.*LP_fpack_GSL_VLDL_Cer ;
    LP_r_prod_GSL_tissue_Cer                    = LP_r_prod_HDL.*LP_fpack_GSL_HDL_Cer ;

    LP_r_prod_GSL_liver_GL1                     = LP_r_prod_VLDL.*LP_fpack_GSL_VLDL_GL1 ;
    LP_r_prod_GSL_tissue_GL1                    = LP_r_prod_HDL.*LP_fpack_GSL_HDL_GL1 ;

    LP_r_prod_GSL_liver_GL2                     = LP_r_prod_VLDL.*LP_fpack_GSL_VLDL_GL2 ;
    LP_r_prod_GSL_tissue_GL2                    = LP_r_prod_HDL.*LP_fpack_GSL_HDL_GL2 ;

    LP_r_prod_GSL_liver_GL3                     = LP_r_prod_VLDL.*LP_fpack_GSL_VLDL_GL3 ;
    LP_r_prod_GSL_tissue_GL3                    = LP_r_prod_HDL.*LP_fpack_GSL_HDL_GL3 ;

    LP_r_prod_GSL_liver_GM3                     = LP_r_prod_VLDL.*LP_fpack_GSL_VLDL_GM3 ;
    LP_r_prod_GSL_tissue_GM3                    = LP_r_prod_HDL.*LP_fpack_GSL_HDL_GM3 ;
  
   
%% flux definitions
   
% liver-compartment

    % specification of common compound factors for fluxes

       f101                                     = parameters(59)*calculated_parameters(77)*parameters(3);
       f102                                     = Liver_GSL_v_storage*calculated_parameters(76)*parameters(2);
       f103                                     = parameters(58)*calculated_parameters(78)*parameters(4);
       f104                                     = Liver_GSL_v_storage*calculated_parameters(79)*parameters(5);    
       
    v101                                        = f101*y(5);
    v102                                        = f102*y(15);
    v103                                        = f103*y(10);
    v104                                        = f104*y(15);
    v105                                        = Liver_GSL_r_efflux_Cer;
    
    v106                                        = f101*y(6);
    v107                                        = f102*y(16);
    v108                                        = f103*y(11);
    v109                                        = f104*y(16);
    v110                                        = Liver_GSL_r_efflux_GL1;
    
    v111                                        = f101*y(7);
    v112                                        = f102*y(17);
    v113                                        = f103*y(12);
    v114                                        = f104*y(17);
    v115                                        = Liver_GSL_r_efflux_GL2;
    
    v116                                        = f101*y(8);
    v117                                        = f102*y(18);
    v118                                        = f103*y(13);
    v119                                        = f104*y(18);
    v120                                        = Liver_GSL_r_efflux_GL3;
    
    v121                                        = f101*y(9);
    v122                                        = f102*y(19);
    v123                                        = f103*y(14);
    v124                                        = f104*y(19);
    v125                                        = Liver_GSL_r_efflux_GM3;
    
    v126                                        = f102*y(15);
    v127                                        = f101*y(5);
    v128                                        = Liver_GSL_r_rxn_golgi_Cer;
    
    v129                                        = f102*y(16);
    v130                                        = f101*y(6);
    v131                                        = Liver_GSL_r_rxn_golgi_GL1;
    
    v132                                        = f102*y(17);
    v133                                        = f101*y(7);
    v134                                        = Liver_GSL_r_rxn_golgi_GL2;
    
    v135                                        = f102*y(18);
    v136                                        = f101*y(8);
    v137                                        = Liver_GSL_r_rxn_golgi_GL3;
    
    v138                                        = f102*y(19);
    v139                                        = f101*y(9);
    v140                                        = Liver_GSL_r_rxn_golgi_GM3;
    
    v141                                        = f104*y(15);
    v142                                        = f103*y(10);
    v143                                        = Liver_GSL_r_rxn_lyso_Cer;
    v144                                        = Liver_GSL_r_uptake_Cer_VLDL + Liver_GSL_r_uptake_Cer_LDL + Liver_GSL_r_uptake_Cer_HDL;
          
    v145                                        = f104*y(16);
    v146                                        = f103*y(11);
    v147                                        = Liver_GSL_r_rxn_lyso_GL1;
    v148                                        = Liver_GSL_r_uptake_GL1_VLDL + Liver_GSL_r_uptake_GL1_LDL + Liver_GSL_r_uptake_GL1_HDL;
    
    v149                                        = f104*y(17);
    v150                                        = f103*y(12);
    v151                                        = Liver_GSL_r_rxn_lyso_GL2;
    v152                                        = Liver_GSL_r_uptake_GL2_VLDL + Liver_GSL_r_uptake_GL2_LDL + Liver_GSL_r_uptake_GL2_HDL;
    
    v153                                        = f104*y(18);
    v154                                        = f103*y(13);
    v155                                        = Liver_GSL_r_rxn_lyso_GL3;
    v156                                        = Liver_GSL_r_uptake_GL3_VLDL + Liver_GSL_r_uptake_GL3_LDL +Liver_GSL_r_uptake_GL3_HDL;
    
    v157                                        = f104*y(19);
    v158                                        = f103*y(14);
    v159                                        = Liver_GSL_r_rxn_lyso_GM3;
    v160                                        = Liver_GSL_r_uptake_GM3_VLDL + Liver_GSL_r_uptake_GM3_LDL + Liver_GSL_r_uptake_GM3_HDL;
    
% tissue compartment


       f201                                     = parameters(63)*calculated_parameters(81)*parameters(7);
       f202                                     = Tissue_GSL_v_storage*calculated_parameters(80)*parameters(6);
       f203                                     = parameters(62)*calculated_parameters(82)*parameters(8);
       f204                                     = Tissue_GSL_v_storage*calculated_parameters(83)*parameters(9);   
    
    v201                                        = f201*y(38);
    v202                                        = f202*y(48);
    v203                                        = f203*y(43);
    v204                                        = f204*y(48);
    v205                                        = Tissue_GSL_r_efflux_Cer;

    v206                                        = f201*y(39);
    v207                                        = f202*y(49);
    v208                                        = f203*y(44);
    v209                                        = f204*y(49);
    v210                                        = Tissue_GSL_r_efflux_GL1;

    v211                                        = f201*y(40);
    v212                                        = f202*y(50);
    v213                                        = f203*y(45);
    v214                                        = f204*y(50);
    v215                                        = Tissue_GSL_r_efflux_GL2;

    v216                                        = f201*y(41);
    v217                                        = f202*y(51);
    v218                                        = f203*y(46);
    v219                                        = f204*y(51);
    v220                                        = Tissue_GSL_r_efflux_GL3;

    v221                                        = f201*y(42);
    v222                                        = f202*y(52);
    v223                                        = f203*y(47);
    v224                                        = f204*y(52);
    v225                                        = Tissue_GSL_r_efflux_GM3;

    v226                                        = f202*y(48);
    v227                                        = f201*y(38);
    v228                                        = Tissue_GSL_r_rxn_golgi_Cer;

    v229                                        = f202*y(49);
    v230                                        = f201*y(39);
    v231                                        = Tissue_GSL_r_rxn_golgi_GL1;

    v232                                        = f202*y(50);
    v233                                        = f201*y(40);
    v234                                        = Tissue_GSL_r_rxn_golgi_GL2;

    v235                                        = f202*y(51);
    v236                                        = f201*y(41);
    v237                                        = Tissue_GSL_r_rxn_golgi_GL3;

    v238                                        = f202*y(52);
    v239                                        = f201*y(42);
    v240                                        = Tissue_GSL_r_rxn_golgi_GM3;

    v241                                        = f204*y(48);
    v242                                        = f203*y(43);
    v243                                        = Tissue_GSL_r_rxn_lyso_Cer;
    v244                                        = Tissue_GSL_r_uptake_Cer_VLDL + Tissue_GSL_r_uptake_Cer_LDL + Tissue_GSL_r_uptake_Cer_HDL;

    v245                                        = f204*y(49);
    v246                                        = f203*y(44);
    v247                                        = Tissue_GSL_r_rxn_lyso_GL1;
    v248                                        = Tissue_GSL_r_uptake_GL1_VLDL + Tissue_GSL_r_uptake_GL1_LDL + Tissue_GSL_r_uptake_GL1_HDL;

    v249                                        = f204*y(50);
    v250                                        = f203*y(45);
    v251                                        = Tissue_GSL_r_rxn_lyso_GL2;
    v252                                        = Tissue_GSL_r_uptake_GL2_VLDL + Tissue_GSL_r_uptake_GL2_LDL + Tissue_GSL_r_uptake_GL2_HDL;

    v253                                        = f204*y(51);
    v254                                        = f203*y(46);
    v255                                        = Tissue_GSL_r_rxn_lyso_GL3;
    v256                                        = Tissue_GSL_r_uptake_GL3_VLDL + Tissue_GSL_r_uptake_GL3_LDL + Tissue_GSL_r_uptake_GL3_HDL;

    v257                                        = f204*y(52);
    v258                                        = f203*y(47);
    v259                                        = Tissue_GSL_r_rxn_lyso_GM3;
    v260                                        = Tissue_GSL_r_uptake_GM3_VLDL + Tissue_GSL_r_uptake_GM3_LDL + Tissue_GSL_r_uptake_GM3_HDL;
  
    
% plasma compartment (lipoproteins)

       f301                                     = LP_r_conv_VLDL_LDL / y(37);
       f302                                     = LP_r_up_liver_VLDL / y(37);
       f303                                     = LP_r_up_tissue_VLDL / y(37);
       f304                                     = parameters(17) * parameters(56);   
       f305                                     = LP_r_up_liver_LDL / y(36);
       f306                                     = LP_r_up_tissue_LDL / y(36);
       f307                                     = LP_r_up_liver_HDL / y(35); 
       

    v301                                        = LP_r_prod_VLDL;
    v302                                        = LP_r_conv_VLDL_LDL;
    v303						                = LP_r_up_liver_VLDL;
    v304						                = LP_r_up_tissue_VLDL;
    v305						                = LP_r_up_liver_LDL;
    v306                                        = LP_r_up_tissue_LDL;
    v307						                = LP_r_prod_HDL;
    v308						                = LP_r_up_liver_HDL;

    v309						                = LP_r_prod_GSL_liver_Cer;
    v310						                = y(22) * f301;
    v311						                = y(22) * f302;
    v312						                = y(22) * f303;

    v313						                = LP_r_prod_GSL_liver_GL1;
    v314						                = y(25) * f301;
    v315						                = y(25) * f302;
    v316						                = y(25) * f303;

    v317						                = LP_r_prod_GSL_liver_GL2;
    v318						                = y(28) * f301;
    v319						                = y(28) * f302;
    v320						                = y(28) * f303;

    v321						                = LP_r_prod_GSL_liver_GL3;
    v322						                = y(31) * f301;
    v323						                = y(31) * f302;
    v324						                = y(31) * f303;

    v325						                = LP_r_prod_GSL_liver_GM3;
    v326						                = y(34) * f301;
    v327						                = y(34) * f302;
    v328						                = y(34) * f303;

    v329						                = y(22) * f304 * f301;
    v330						                = y(21) * f305;
    v331						                = y(21) * f306;

    v332						                = y(25) * f304 * f301;
    v333						                = y(24) * f305;
    v334						                = y(24) * f306;

    v335						                = y(28) * f304 * f301;
    v336						                = y(27) * f305;
    v337						                = y(27) * f306;

    v338						                = y(31) * f304 * f301;
    v339						                = y(30) * f305;
    v340						                = y(30) * f306;

    v341						                = y(34) * f304 * f301;
    v342						                = y(33) * f305;
    v343						                = y(33) * f306;

    v344						                = LP_r_prod_GSL_tissue_Cer;
    v345						                = y(20) * f307;

    v346						                = LP_r_prod_GSL_tissue_GL1;
    v347						                = y(23) * f307;

    v348						                = LP_r_prod_GSL_tissue_GL2;
    v349						                = y(26) * f307;

    v350						                = LP_r_prod_GSL_tissue_GL3;
    v351						                = y(29) * f307;

    v352						                = LP_r_prod_GSL_tissue_GM3;
    v353						                = y(32) * f307;    
    

%% ode definitions

% preallocate column vector
    dydt                                        = zeros(n_state_variables,1);

    
    dydt(15)         = ( v101 - v102 + v103 - v104 - v105 )/Liver_GSL_v_storage ;                         
    dydt(16)         = ( v106 - v107 + v108 - v109 - v110 )/Liver_GSL_v_storage ;     
    dydt(17)         = ( v111 - v112 + v113 - v114 - v115 )/Liver_GSL_v_storage ;                          
    dydt(18)         = ( v116 - v117 + v118 - v119 - v120 )/Liver_GSL_v_storage ;                                                                                
    dydt(19)         = ( v121 - v122 + v123 - v124 - v125 )/Liver_GSL_v_storage ;
    
    dydt(5)           = ( v126 - v127 + v128 ) / parameters(59);                    
    dydt(6)           = ( v129 - v130 + v131 ) / parameters(59);                    
    dydt(7)           = ( v132 - v133 + v134 ) / parameters(59);                    
    dydt(8)           = ( v135 - v136 + v137 ) / parameters(59); 
    dydt(9)           = ( v138 - v139 + v140 ) / parameters(59);

    dydt(10)            = ( v141 - v142 + v143 + v144 ) / parameters(58);                 
    dydt(11)            = ( v145 - v146 + v147 + v148 ) / parameters(58);                 
    dydt(12)            = ( v149 - v150 + v151 + v152 ) / parameters(58);
    dydt(13)            = ( v153 - v154 + v155 + v156 ) / parameters(58);                 
    dydt(14)            = ( v157 - v158 + v159 + v160 ) / parameters(58);    

    dydt(48)        = ( v201 - v202 + v203 - v204 - v205 )/Tissue_GSL_v_storage ;                         
    dydt(49)        = ( v206 - v207 + v208 - v209 - v210 )/Tissue_GSL_v_storage ;     
    dydt(50)        = ( v211 - v212 + v213 - v214 - v215 )/Tissue_GSL_v_storage ;                          
    dydt(51)        = ( v216 - v217 + v218 - v219 - v220 )/Tissue_GSL_v_storage ;                                                                                
    dydt(52)        = ( v221 - v222 + v223 - v224 - v225 )/Tissue_GSL_v_storage ;

    dydt(38)          = ( v226 - v227 + v228 ) / parameters(63);                    
    dydt(39)          = ( v229 - v230 + v231 ) / parameters(63);                    
    dydt(40)          = ( v232 - v233 + v234 ) / parameters(63);                    
    dydt(41)          = ( v235 - v236 + v237 ) / parameters(63); 
    dydt(42)          = ( v238 - v239 + v240 ) / parameters(63);

    dydt(43)           = ( v241 - v242 + v243 + v244 ) / parameters(62);
    dydt(44)           = ( v245 - v246 + v247 + v248 ) / parameters(62);
    dydt(45)           = ( v249 - v250 + v251 + v252) / parameters(62);
    dydt(46)           = ( v253 - v254 + v255 + v256 ) / parameters(62);
    dydt(47)           = ( v257 - v258 + v259 + v260 ) / parameters(62);
            
    dydt(37)                    = ( v301 - v302 - v303 - v304 ) / parameters(65); 
    dydt(36)                     = ( v302 - v305 - v306 ) / parameters(65) ; 
    dydt(35)                     = ( v307 - v308  ) / parameters(65) ;

    dydt(22)                   = ( v309 - v310 - v311 - v312 ) / parameters(65) ;                
    dydt(25)                   = ( v313 - v314 - v315 - v316 ) / parameters(65) ;
    dydt(28)                   = ( v317 - v318 - v319 - v320 ) / parameters(65) ;                     
    dydt(31)                   = ( v321 - v322 - v323 - v324 ) / parameters(65) ;                     
    dydt(34)                   = ( v325 - v326 - v327 - v328 ) / parameters(65) ;                     

    dydt(21)                    = ( v329 - v330 - v331 )/ parameters(65) ;  
    dydt(24)                    = ( v332 - v333 - v334 )/ parameters(65) ;  
    dydt(27)                    = ( v335 - v336 - v337 )/ parameters(65) ;
    dydt(30)                    = ( v338 - v339 - v340 )/ parameters(65) ;
    dydt(33)                    = ( v341 - v342 - v343 )/ parameters(65) ;                                        
                                     
    dydt(20)                    = ( v344 - v345 )/ parameters(65);
    dydt(23)                    = ( v346 - v347 )/ parameters(65);
    dydt(26)                    = ( v348 - v349 )/ parameters(65);
    dydt(29)                    = ( v350 - v351 )/ parameters(65);
    dydt(32)                    = ( v352 - v353 )/ parameters(65);

end
