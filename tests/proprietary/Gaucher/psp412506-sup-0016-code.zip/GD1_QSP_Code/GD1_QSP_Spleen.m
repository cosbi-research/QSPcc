function dydt = GD1_QSP_Spleen(time, y, parameters)
% %%spleen macrophage model



%% spleen macrophage model - rates and fluxes

% unit conversions

    % conversion of concentrations to numbers of GL1 molecules
    spleen_macrophage_N_GL1_lyso                = parameters(4)*y(9) ;
    
% GL-1- and ceramide-related

    spleen_macrophage_flux_to_inclusion         = parameters(4)*parameters(17)*1e5*(y(9) - y(7)/parameters(3)/1e4) ;
    spleen_macrophage_flux_from_inclusion       = 0 ;
    spleen_macrophage_flux_GL1_deg              = parameters(4)*parameters(34)*parameters(12)*y(9)/(parameters(13)+y(9)) ;    
    spleen_macrophage_N_GL1_total               = y(7)+spleen_macrophage_N_GL1_lyso ;
    spleen_macrophage_phi_total                 = 1-max(1e-9,spleen_macrophage_N_GL1_total)^parameters(19)/(max(1e-9,spleen_macrophage_N_GL1_total)^parameters(19)+parameters(18)^parameters(19)) ;
    spleen_macrophage_rate_uptake_CER           = spleen_macrophage_phi_total*parameters(1)*parameters(8) ; 
    spleen_macrophage_rate_uptake_GL1           = spleen_macrophage_phi_total*parameters(1)*parameters(7) ; 
    spleen_macrophage_flux_CER_to_GL1           = spleen_macrophage_adj_CER_conv*parameters(5)*parameters(14)*y(11)/(parameters(15)+y(11)) ; 
    spleen_macrophage_flux_CER_deg              =  parameters(5)*parameters(12)*y(11)/(parameters(13)+y(11)) ;

% lyso-GL1-related

    spleen_macrophage_flux_lyso_GL1_syn_bulk    = parameters(9)*y(7); 
    spleen_macrophage_flux_lyso_GL1_syn_lyso    = parameters(4)*parameters(10)*y(9)/(parameters(16)+y(9)) ; 
    spleen_macrophage_flux_in_GSL               = spleen_macrophage_rate_uptake_GL1 + spleen_macrophage_flux_CER_to_GL1;
    S_phi_enhanced                              = ((y(7)))^2/max(1e-9,(((y(7)))^2+parameters(23)^2));

    
%% ode definitions

% preallocate column vector
    dydt                                        = zeros(12,1);


% spleen macrophage-related

    dydt(7)    = spleen_macrophage_flux_to_inclusion - spleen_macrophage_flux_from_inclusion - spleen_macrophage_flux_lyso_GL1_syn_bulk ;    
    dydt(9)      = (spleen_macrophage_flux_in_GSL - spleen_macrophage_flux_GL1_deg - spleen_macrophage_flux_lyso_GL1_syn_lyso - spleen_macrophage_flux_to_inclusion + spleen_macrophage_flux_from_inclusion )/parameters(4) ;
    dydt(10) = ((parameters(2)/parameters(1))*(spleen_macrophage_flux_lyso_GL1_syn_lyso + spleen_macrophage_flux_lyso_GL1_syn_bulk) - parameters(6)*parameters(11)*y(10) )/parameters(6) ;
    dydt(11)      = ( spleen_macrophage_rate_uptake_CER - spleen_macrophage_flux_CER_to_GL1 + spleen_macrophage_flux_GL1_deg  - spleen_macrophage_flux_CER_deg )/parameters(5) ;
    dydt(5)= spleen_macrophage_flux_GL1_deg ;
    dydt(6) = spleen_macrophage_flux_in_GSL ;
    dydt(8) = spleen_macrophage_flux_lyso_GL1_syn_lyso + spleen_macrophage_flux_lyso_GL1_syn_bulk ;    
    dydt(12)                   = parameters(20)*(1-spleen_macrophage_phi_total)*(parameters(24)-y(12)) - parameters(21)*spleen_macrophage_phi_total*(y(12)-parameters(25))  - parameters(22)*S_phi_enhanced ;                     


end

