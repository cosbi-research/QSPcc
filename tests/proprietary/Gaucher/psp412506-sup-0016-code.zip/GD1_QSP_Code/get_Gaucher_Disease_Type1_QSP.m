function [parameters, calculated_parameters] = get_Gaucher_Disease_Type1_QSP(theta)
parameters = zeros(67,1);
calculated_parameters = zeros(83,1);
%% physical constants
NAv                             = 6.02E23       ;                               % [%] Avogadro's number, 6.02E23

    parameters(1)               = NAv;

    
%% inter-compartment transfer rates

% liver
Liver_GSL_k_storage_to_golgi    = log(2)/(15/60) ;                              % transfer rate from storage to golgi, t1/2 ~ 15 min ==>  1/hr
Liver_GSL_k_golgi_to_storage    = 1/(20/60)      ;                              % transfer rate from golgi to storage, transit time ~ 20 min ==>  1/hr
Liver_GSL_k_lyso_to_storage     = 1/2            ;                              % transfer rate from lyso to storage, transit time   1/hr
Liver_GSL_k_storage_to_lyso     = log(2)/10      ;                              % transfer rate from storage to lyso, t1/2 ~ 10 hrs ==>  1/hr

    parameters(2)               = Liver_GSL_k_storage_to_golgi;
    parameters(3)               = Liver_GSL_k_golgi_to_storage;
    parameters(4)               = Liver_GSL_k_lyso_to_storage;
    parameters(5)               = Liver_GSL_k_storage_to_lyso;
    
% other tissues
Tissue_GSL_k_storage_to_golgi   = log(2)/(15/60) ;                              % transfer rate from storage to golgi, t1/2 ~ 15 min ==>  1/hr
Tissue_GSL_k_golgi_to_storage   = 1/(20/60)      ;                              % transfer rate from golgi to storage, transit time ~ 20 min ==>  1/hr
Tissue_GSL_k_lyso_to_storage    = 1/2            ;                              % transfer rate from lyso to storage, transit time  1/hr
Tissue_GSL_k_storage_to_lyso    = log(2)/10      ;                              % transfer rate from storage to lyso, t1/2 ~ 10 hrs ==>  1/hr

    parameters(6)               = Tissue_GSL_k_storage_to_golgi;
    parameters(7)               = Tissue_GSL_k_golgi_to_storage;
    parameters(8)               = Tissue_GSL_k_lyso_to_storage;
    parameters(9)              = Tissue_GSL_k_storage_to_lyso;
    
%% lipoprotein-related 

% production, conversion, and uptake rates 
LP_adj_k_prod_VLDL              = 0.544404 ;            
LP_adj_k_prod_HDL               = 1.19698 ; 
LP_adj_k_conv_VLDL_LDL          = 0.709464 ;  
LP_adj_k_up_liver_VLDL          = 0.217868 ;  
LP_adj_k_up_liver_LDL           = 0.268775 ; 
LP_adj_k_up_liver_HDL           = 1.355654 ; 
LP_adj_ratio_up_liver_tissue    = 0.066183 ; 

LP_adj_fGSL_loss                = 0.948438 ; 

    parameters(10)              = LP_adj_k_prod_VLDL;
    parameters(11)              = LP_adj_k_prod_HDL;
    parameters(12)              = LP_adj_k_conv_VLDL_LDL;
    parameters(13)              = LP_adj_k_up_liver_VLDL;
    parameters(14)              = LP_adj_k_up_liver_LDL;
    parameters(15)              = LP_adj_k_up_liver_HDL;
    parameters(16)              = LP_adj_ratio_up_liver_tissue;
    parameters(17)              = LP_adj_fGSL_loss;

% production, conversion, and uptake rates
LP_k_prod_VLDL                  = 0.0367 ;                                      % [umol/(l.h)] VLDL production rate from liver per plasma volume 
LP_k_prod_HDL                   = 0.126 ;                                       % [umol/(l.h)] HDL production rate from tissue per plasma volume
LP_k_conv_VLDL_LDL              = 0.0786 ;                                      % [1/h] first order rate constant of VLDL to LDL conversion 
LP_k_up_liver_VLDL              = 0.104 ;                                       % [1/h] first order rate constant of VLDL uptake to liver
LP_k_up_liver_LDL               = 0.00722 ;                                     % [1/h] first order rate constant of LDL uptake to liver
LP_k_up_liver_HDL               = 0.00722 ;                                     % [1/h] first order rate constant of HDL uptake to liver
LP_ratio_up_liver_tissue        = 7 ;                                           % [-] ratio of liver and tissue uptake rate for VLDL and LDL

    parameters(18)              = LP_k_prod_VLDL;
    parameters(19)              = LP_k_prod_HDL;
    parameters(20)              = LP_k_conv_VLDL_LDL;
    parameters(21)              = LP_k_up_liver_VLDL;
    parameters(22)              = LP_k_up_liver_LDL;
    parameters(23)              = LP_k_up_liver_HDL;
    parameters(24)              = LP_ratio_up_liver_tissue;    
      


%% enzyme kinetics

% ceramide-related
Liver_GSL_KM_Cer                = theta(12) ; 	
Liver_GSL_adj_rp_Cer            = theta(8) ;                                     
Liver_GSL_E_max_cer_reg         = 1.01172 ; 	
Liver_GSL_K_cer_reg             = 1228.7 ;	
Liver_GSL_h_cer_reg             = 10 ; 	

Liver_GSL_rp_Cer                = 10 ;                                          %  [1/hr]

Tissue_GSL_KM_Cer               = theta(13) ; 	
Tissue_GSL_adj_rp_Cer           = theta(9) ;                                     
Tissue_GSL_E_max_cer_reg        = theta(14) ; 	
Tissue_GSL_K_cer_reg            = theta(15) ; 	
Tissue_GSL_h_cer_reg            = theta(16) ; 	

Tissue_GSL_rp_Cer               = 1 ;                                           % [1/hr]        

    parameters(33)              = Liver_GSL_KM_Cer;
    parameters(34)              = Liver_GSL_adj_rp_Cer;
    parameters(35)              = Liver_GSL_E_max_cer_reg;
    parameters(36)              = Liver_GSL_K_cer_reg;
    parameters(37)              = Liver_GSL_h_cer_reg;
    
    parameters(38)             = Liver_GSL_rp_Cer;
    
    parameters(39)             = Tissue_GSL_KM_Cer;
    parameters(40)             = Tissue_GSL_adj_rp_Cer; 
    parameters(41)             = Tissue_GSL_E_max_cer_reg; 
    parameters(42)             = Tissue_GSL_K_cer_reg; 
    parameters(43)             = Tissue_GSL_h_cer_reg; 
    
    parameters(44)             = Tissue_GSL_rp_Cer;     

%% degradation and concentration

Gaucher_par                     = theta(18);	 

Liver_GSL_adj_GL1D              = Gaucher_par ;
Tissue_GSL_adj_GL1D             = Gaucher_par ;
spleen_macrophage_adj_GL1_deg   = Gaucher_par;

Liver_GSL_adj_GL3D              = 1 ; 
Tissue_GSL_adj_GL3D             = 1 ; 

Liver_GSL_adj_c_e               = 1 ;                                           
Tissue_GSL_adj_c_e              = 1 ;

 
    parameters(45)              = Liver_GSL_adj_GL1D;   
    parameters(46)              = Tissue_GSL_adj_GL1D;   
    parameters(47)              = spleen_macrophage_adj_GL1_deg;   
    
    parameters(48)              = Liver_GSL_adj_GL3D;   
    parameters(49)              = Tissue_GSL_adj_GL3D;   
    
    parameters(50)              = Liver_GSL_adj_c_e;   
    parameters(51)              = Tissue_GSL_adj_c_e;       

%% GSL and lipoprotein related

Liver_GSL_total_GSL_organ_wild  = 32.7 ;                                        % [uM] 
Tissue_GSL_total_GSL_organ_wild = 32.7 ;                                        % [uM]  

    parameters(52)             = Liver_GSL_total_GSL_organ_wild;   
    parameters(53)             = Tissue_GSL_total_GSL_organ_wild;         
        
% GSL packing related
LP_fpack_total_GSL_VLDL_wild    = 15 ;                                          % [mol/mol] 
LP_fpack_total_GSL_HDL_wild     = 1.5;                                          % [mol/mol] 
LP_fGSL_loss = 0.5 ;                                                            

    parameters(54)             = LP_fpack_total_GSL_VLDL_wild;  
    parameters(55)             = LP_fpack_total_GSL_HDL_wild;   
    parameters(56)             = LP_fGSL_loss;      

% volumes
Liver_GSL_v_organ               = 1.371 ;                                       % [L] 
Liver_GSL_v_lyso                = 1.371*2/100  ;                                % [L] 
Liver_GSL_v_golgi               = 1.371*0.5/100 ;                               % [L] 
Liver_GSL_v_cell                = 3.4E-12  ;                                    % [L] 

Tissue_GSL_v_organ              = 52.58 ;                                       % [L] 
Tissue_GSL_v_lyso               = 52.58*2/100  ;                                % [L] 
Tissue_GSL_v_golgi              = 52.58*0.5/100 ;                               % [L] 
Tissue_GSL_v_cell               = 1.0E-12  ;                                    % [L] 

LP_v_plasma                     = 3.126 ;                                       % [L] volume of total plasma of 71kg BM
LP_v_liver                      = 1.371 ;                                       % [L] cellular volume of total hepatocyte
LP_v_tissue                     = 52.58 ;                                       % [L] cellular volume of all other tissues except liver

    parameters(57)              = Liver_GSL_v_organ;  
    parameters(58)              = Liver_GSL_v_lyso;  
    parameters(59)              = Liver_GSL_v_golgi;      
    parameters(60)              = Liver_GSL_v_cell;  
    
    parameters(61)              = Tissue_GSL_v_organ;  
    parameters(62)              = Tissue_GSL_v_lyso;      
    parameters(63)              = Tissue_GSL_v_golgi;  
    parameters(64)              = Tissue_GSL_v_cell;  
    
    parameters(65)              = LP_v_plasma;    
    parameters(66)              = LP_v_liver; 
    parameters(67)              = LP_v_tissue; 

%% 

% base parameters
KM_GL2S                         = theta(10) ; 	
KM_GL3S                         = 0.50011 ; 	 
KM_GM3S                         = theta(11) ; 	
KM_GL1S                         = 0.04E3 ;                                      % [uM]
KM_GL1D                         = 0.2E3 ;                                       % [uM]
KM_GL2D                         = 0.03E3 ;                                      % [uM] 
KM_GL3D                         = 8.3E3 ;                                       % [uM] 
KM_GM3D                         = 0.146E3;                                      % [uM] 
      
kcat_GL1S                       = 433;                                          % [1/hr] 
kcat_GL1D                       = 29880;                                        % [1/hr] 
kcat_GL2S                       = 165.51;                                       % [1/hr] 
kcat_GL2D                       = 103.2;                                        % [1/hr] 
kcat_GL3S                       = 10.7 ;                                        % [1/hr]
kcat_GL3D                       = 16589;                                        % [1/hr] 
kcat_GM3S                       = 2.25;                                         % [1/hr] 
kcat_GM3D                       = 21.6;                                         % [1/hr] 

adj_kcat_GL1S                   = theta(1) ; 	
adj_kcat_GL1D                   = theta(2) ; 	
adj_kcat_GL2S                   = theta(3) ; 	
adj_kcat_GL2D                   = theta(4) ; 	
adj_kcat_GL3S                   = theta(5) ; 	
adj_kcat_GL3D                   = 4.99943 ; 	
adj_kcat_GM3S                   = theta(6) ;	
adj_kcat_GM3D                   = theta(7) ;	 

% enzyme numbers
N_GL1S                          = 20000 ;                                       % [%/cell] 
N_GL1D                          = 20000 ;                                       % [%/cell] 
N_GL2S                          = 20000 ;                                       % [%/cell] 
N_GL2D                          = 20000 ;                                       % [%/cell] 
N_GL3S                          = 20000 ;                                       % [%/cell] 
N_GL3D                          = 20000 ;                                       % [%/cell] 
N_GM3S                          = 20000 ;                                       % [%/cell] 
N_GM3D                          = 20000 ;                                       % [%/cell] 
  
% inter-compartment transfer rates
adj_storage_to_golgi_par        = 0.532805 ;     
adj_golgi_to_storage_par        = 2.80241 ;      
adj_lyso_to_storage_par         = 1.82048 ;      
adj_storage_to_lyso_par         = 1.98408 ;       
   
%% 

% propagation to tissue-specific parameters
Liver_GSL_KM_GL1S                               = KM_GL1S; 
Liver_GSL_KM_GL1D                               = KM_GL1D; 
Liver_GSL_KM_GL2S                               = KM_GL2S; 
Liver_GSL_KM_GL2D                               = KM_GL2D; 
Liver_GSL_KM_GL3S                               = KM_GL3S; 
Liver_GSL_KM_GL3D                               = KM_GL3D; 
Liver_GSL_KM_GM3S                               = KM_GM3S; 
Liver_GSL_KM_GM3D                               = KM_GM3D;   

    calculated_parameters(1)                    = Liver_GSL_KM_GL1S;
    calculated_parameters(2)                    = Liver_GSL_KM_GL1D;
    calculated_parameters(3)                    = Liver_GSL_KM_GL2S;
    calculated_parameters(4)                    = Liver_GSL_KM_GL2D;
    calculated_parameters(5)                    = Liver_GSL_KM_GL3S;
    calculated_parameters(6)                    = Liver_GSL_KM_GL3D;
    calculated_parameters(7)                    = Liver_GSL_KM_GM3S;
    calculated_parameters(8)                    = Liver_GSL_KM_GM3D;

Tissue_GSL_KM_GL1S                              = KM_GL1S; 
Tissue_GSL_KM_GL1D                              = KM_GL1D; 
Tissue_GSL_KM_GL2S                              = KM_GL2S; 
Tissue_GSL_KM_GL2D                              = KM_GL2D; 
Tissue_GSL_KM_GL3S                              = KM_GL3S; 
Tissue_GSL_KM_GL3D                              = KM_GL3D; 
Tissue_GSL_KM_GM3S                              = KM_GM3S; 
Tissue_GSL_KM_GM3D                              = KM_GM3D; 

    calculated_parameters(9)                    = Tissue_GSL_KM_GL1S;
    calculated_parameters(10)                   = Tissue_GSL_KM_GL1D;
    calculated_parameters(11)                   = Tissue_GSL_KM_GL2S;
    calculated_parameters(12)                   = Tissue_GSL_KM_GL2D;
    calculated_parameters(13)                   = Tissue_GSL_KM_GL3S;
    calculated_parameters(14)                   = Tissue_GSL_KM_GL3D;
    calculated_parameters(15)                   = Tissue_GSL_KM_GM3S;
    calculated_parameters(16)                   = Tissue_GSL_KM_GM3D;

Liver_GSL_kcat_GL1S                             = kcat_GL1S; 
Liver_GSL_kcat_GL1D                             = kcat_GL1D; 
Liver_GSL_kcat_GL2S                             = kcat_GL2S; 
Liver_GSL_kcat_GL2D                             = kcat_GL2D; 
Liver_GSL_kcat_GL3S                             = kcat_GL3S; 
Liver_GSL_kcat_GL3D                             = kcat_GL3D; 
Liver_GSL_kcat_GM3S                             = kcat_GM3S; 
Liver_GSL_kcat_GM3D                             = kcat_GM3D;     

    calculated_parameters(17)                   = Liver_GSL_kcat_GL1S;
    calculated_parameters(18)                   = Liver_GSL_kcat_GL1D;
    calculated_parameters(19)                   = Liver_GSL_kcat_GL2S;
    calculated_parameters(20)                   = Liver_GSL_kcat_GL2D;
    calculated_parameters(21)                   = Liver_GSL_kcat_GL3S;
    calculated_parameters(22)                   = Liver_GSL_kcat_GL3D;
    calculated_parameters(23)                   = Liver_GSL_kcat_GM3S;
    calculated_parameters(24)                   = Liver_GSL_kcat_GM3D;

Tissue_GSL_kcat_GL1S                            = kcat_GL1S; 
Tissue_GSL_kcat_GL1D                            = kcat_GL1D; 
Tissue_GSL_kcat_GL2S                            = kcat_GL2S; 
Tissue_GSL_kcat_GL2D                            = kcat_GL2D; 
Tissue_GSL_kcat_GL3S                            = kcat_GL3S; 
Tissue_GSL_kcat_GL3D                            = kcat_GL3D; 
Tissue_GSL_kcat_GM3S                            = kcat_GM3S; 
Tissue_GSL_kcat_GM3D                            = kcat_GM3D;  

    calculated_parameters(25)                   = Tissue_GSL_kcat_GL1S;
    calculated_parameters(26)                   = Tissue_GSL_kcat_GL1D;
    calculated_parameters(27)                   = Tissue_GSL_kcat_GL2S;
    calculated_parameters(28)                   = Tissue_GSL_kcat_GL2D;
    calculated_parameters(29)                   = Tissue_GSL_kcat_GL3S;
    calculated_parameters(30)                   = Tissue_GSL_kcat_GL3D;
    calculated_parameters(31)                   = Tissue_GSL_kcat_GM3S;
    calculated_parameters(32)                   = Tissue_GSL_kcat_GM3D;

Liver_GSL_adj_kcat_GL1S                         = adj_kcat_GL1S; 
Liver_GSL_adj_kcat_GL1D                         = adj_kcat_GL1D; 
Liver_GSL_adj_kcat_GL2S                         = adj_kcat_GL2S; 
Liver_GSL_adj_kcat_GL2D                         = adj_kcat_GL2D;  
Liver_GSL_adj_kcat_GL3S                         = adj_kcat_GL3S;  
Liver_GSL_adj_kcat_GL3D                         = adj_kcat_GL3D; 
Liver_GSL_adj_kcat_GM3S                         = adj_kcat_GM3S;  
Liver_GSL_adj_kcat_GM3D                         = adj_kcat_GM3D; 

    calculated_parameters(33)                   = Liver_GSL_adj_kcat_GL1S;
    calculated_parameters(34)                   = Liver_GSL_adj_kcat_GL1D;
    calculated_parameters(35)                   = Liver_GSL_adj_kcat_GL2S;
    calculated_parameters(36)                   = Liver_GSL_adj_kcat_GL2D;
    calculated_parameters(37)                   = Liver_GSL_adj_kcat_GL3S;
    calculated_parameters(38)                   = Liver_GSL_adj_kcat_GL3D;
    calculated_parameters(39)                   = Liver_GSL_adj_kcat_GM3S;
    calculated_parameters(40)                   = Liver_GSL_adj_kcat_GM3D;

Tissue_GSL_adj_kcat_GL1S                        = adj_kcat_GL1S; 
Tissue_GSL_adj_kcat_GL1D                        = adj_kcat_GL1D; 
Tissue_GSL_adj_kcat_GL2S                        = adj_kcat_GL2S; 
Tissue_GSL_adj_kcat_GL2D                        = adj_kcat_GL2D;  
Tissue_GSL_adj_kcat_GL3S                        = adj_kcat_GL3S;  
Tissue_GSL_adj_kcat_GL3D                        = adj_kcat_GL3D; 
Tissue_GSL_adj_kcat_GM3S                        = adj_kcat_GM3S;  
Tissue_GSL_adj_kcat_GM3D                        = adj_kcat_GM3D;     

    calculated_parameters(41)                   = Tissue_GSL_adj_kcat_GL1S;
    calculated_parameters(42)                   = Tissue_GSL_adj_kcat_GL1D;
    calculated_parameters(43)                   = Tissue_GSL_adj_kcat_GL2S;
    calculated_parameters(44)                   = Tissue_GSL_adj_kcat_GL2D;
    calculated_parameters(45)                   = Tissue_GSL_adj_kcat_GL3S;
    calculated_parameters(46)                   = Tissue_GSL_adj_kcat_GL3D;
    calculated_parameters(47)                   = Tissue_GSL_adj_kcat_GM3S;
    calculated_parameters(48)                   = Tissue_GSL_adj_kcat_GM3D;

Liver_GSL_N_GL1S                                = N_GL1S; 
Liver_GSL_N_GL1D                                = N_GL1D; 
Liver_GSL_N_GL2S                                = N_GL2S; 
Liver_GSL_N_GL2D                                = N_GL2D; 
Liver_GSL_N_GL3S                                = N_GL3S; 
Liver_GSL_N_GL3D                                = N_GL3D; 
Liver_GSL_N_GM3S                                = N_GM3S; 
Liver_GSL_N_GM3D                                = N_GM3D;         

    calculated_parameters(49)                   = Liver_GSL_N_GL1S;
    calculated_parameters(50)                   = Liver_GSL_N_GL1D;
    calculated_parameters(51)                   = Liver_GSL_N_GL2S;
    calculated_parameters(52)                   = Liver_GSL_N_GL2D;
    calculated_parameters(53)                   = Liver_GSL_N_GL3S;
    calculated_parameters(54)                   = Liver_GSL_N_GL3D;
    calculated_parameters(55)                   = Liver_GSL_N_GM3S;
    calculated_parameters(56)                   = Liver_GSL_N_GM3D;

Tissue_GSL_N_GL1S                               = N_GL1S; 
Tissue_GSL_N_GL1D                               = N_GL1D; 
Tissue_GSL_N_GL2S                               = N_GL2S; 
Tissue_GSL_N_GL2D                               = N_GL2D; 
Tissue_GSL_N_GL3S                               = N_GL3S; 
Tissue_GSL_N_GL3D                               = N_GL3D; 
Tissue_GSL_N_GM3S                               = N_GM3S; 
Tissue_GSL_N_GM3D                               = N_GM3D;    

    calculated_parameters(57)                   = Tissue_GSL_N_GL1S;
    calculated_parameters(58)                   = Tissue_GSL_N_GL1D;
    calculated_parameters(59)                   = Tissue_GSL_N_GL2S;
    calculated_parameters(60)                   = Tissue_GSL_N_GL2D;
    calculated_parameters(61)                   = Tissue_GSL_N_GL3S;
    calculated_parameters(62)                   = Tissue_GSL_N_GL3D;
    calculated_parameters(63)                   = Tissue_GSL_N_GM3S;
    calculated_parameters(64)                   = Tissue_GSL_N_GM3D;
                

% connection between liver/tissue and plasma for LP production/uptake, GSL paacking related
Liver_GSL_k_up_organ_VLDL                       = LP_adj_k_up_liver_VLDL*LP_k_up_liver_VLDL ;
Liver_GSL_k_up_organ_LDL                        = LP_adj_k_up_liver_LDL*LP_k_up_liver_LDL ;
Liver_GSL_k_up_organ_HDL                        = LP_adj_k_up_liver_HDL*LP_k_up_liver_HDL ; 
Liver_GSL_fpack_total_GSL_LP_wild               = LP_fpack_total_GSL_VLDL_wild ; % [umol/umol] 
 
Liver_GSL_r_prod_LP                             = LP_k_prod_VLDL*LP_adj_k_prod_VLDL*LP_v_plasma ; % [umol/h] 

    calculated_parameters(65)                   = Liver_GSL_k_up_organ_VLDL;
    calculated_parameters(66)                   = Liver_GSL_k_up_organ_LDL;
    calculated_parameters(67)                   = Liver_GSL_k_up_organ_HDL;
    calculated_parameters(68)                   = Liver_GSL_fpack_total_GSL_LP_wild;
    calculated_parameters(69)                   = Liver_GSL_r_prod_LP;

Tissue_GSL_k_up_organ_VLDL                      = LP_adj_k_up_liver_VLDL*LP_k_up_liver_VLDL/(LP_adj_ratio_up_liver_tissue*LP_ratio_up_liver_tissue) ;
Tissue_GSL_k_up_organ_LDL                       = LP_adj_k_up_liver_LDL*LP_k_up_liver_LDL/(LP_adj_ratio_up_liver_tissue*LP_ratio_up_liver_tissue) ; 
Tissue_GSL_k_up_organ_HDL                       = 0 ; 
Tissue_GSL_fpack_total_GSL_LP_wild              = LP_fpack_total_GSL_HDL_wild ; 

Tissue_GSL_r_prod_LP                            = LP_adj_k_prod_HDL*LP_k_prod_HDL*LP_v_plasma ; 

    calculated_parameters(70)                   = Tissue_GSL_k_up_organ_VLDL;
    calculated_parameters(71)                   = Tissue_GSL_k_up_organ_LDL;
    calculated_parameters(72)                   = Tissue_GSL_k_up_organ_HDL;
    calculated_parameters(73)                   = Tissue_GSL_fpack_total_GSL_LP_wild;
    calculated_parameters(74)                   = Tissue_GSL_r_prod_LP;
    
LP_total_GSL_tissue_wild                        = Tissue_GSL_total_GSL_organ_wild ;  

Liver_GSL_adj_storage_to_golgi                  = adj_storage_to_golgi_par ;
Liver_GSL_adj_golgi_to_storage                  = adj_golgi_to_storage_par ;
Liver_GSL_adj_lyso_to_storage                   = adj_lyso_to_storage_par ;
Liver_GSL_adj_storage_to_lyso                   = adj_storage_to_lyso_par ;
  
Tissue_GSL_adj_storage_to_golgi                 = adj_storage_to_golgi_par ;
Tissue_GSL_adj_golgi_to_storage                 = adj_golgi_to_storage_par ;
Tissue_GSL_adj_lyso_to_storage                  = adj_lyso_to_storage_par ;
Tissue_GSL_adj_storage_to_lyso                  = adj_storage_to_lyso_par ;

    calculated_parameters(75)                   = LP_total_GSL_tissue_wild;
    
    calculated_parameters(76)                   = Liver_GSL_adj_storage_to_golgi;
    calculated_parameters(77)                   = Liver_GSL_adj_golgi_to_storage;
    calculated_parameters(78)                   = Liver_GSL_adj_lyso_to_storage;
    calculated_parameters(79)                   = Liver_GSL_adj_storage_to_lyso;
    
    calculated_parameters(80)                   = Tissue_GSL_adj_storage_to_golgi;
    calculated_parameters(81)                   = Tissue_GSL_adj_golgi_to_storage;
    calculated_parameters(82)                   = Tissue_GSL_adj_lyso_to_storage;
    calculated_parameters(83)                   = Tissue_GSL_adj_storage_to_lyso;

 
end

