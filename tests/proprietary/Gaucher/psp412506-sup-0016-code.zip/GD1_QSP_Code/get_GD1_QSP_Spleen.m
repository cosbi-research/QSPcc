function parameters = get_GD1_QSP_Spleen(theta)
parameters = zeros(34,1);

%% spleen macrophage-related parameters

% cell numbers
spleen_macrophage_N_Gaucher_cells              = 1.3e10 ;                       % [number]
spleen_macrophage_N_Gaucher_whole_body         = 1*1.3e10 ;                     % [number]

    parameters(1)              = spleen_macrophage_N_Gaucher_cells;    
    parameters(2)              = spleen_macrophage_N_Gaucher_whole_body;      

% volumes
spleen_macrophage_V_macrophage_pL              = 5        ;                     % [pL]
spleen_macrophage_V_macrophage                 = spleen_macrophage_N_Gaucher_cells*(spleen_macrophage_V_macrophage_pL/1e12)         ; % [L] total 
spleen_macrophage_V_lyso                       = spleen_macrophage_N_Gaucher_cells*(spleen_macrophage_V_macrophage_pL/1e12)*(2/100) ; % [L] total 
spleen_macrophage_V_Cer                        = spleen_macrophage_N_Gaucher_cells*(spleen_macrophage_V_macrophage_pL/1e12)*(0.5/100) ;
spleen_macrophage_V_plasma                     = 3            ;                 % [L]

    parameters(3)              = spleen_macrophage_V_macrophage;
    parameters(4)              = spleen_macrophage_V_lyso;
    parameters(5)              = spleen_macrophage_V_Cer;
    parameters(6)              = spleen_macrophage_V_plasma;
    
% intake rates
spleen_macrophage_rate_GL1_phago               = 200*4.125E-12 ;                % [umol/hr/cell] 
spleen_macrophage_rate_CER_phago               = 200*8.333E-11 ;                % [umol/hr/cell] 
    
    parameters(7)              = spleen_macrophage_rate_GL1_phago;
    parameters(8)              = spleen_macrophage_rate_CER_phago;
    
% synthesis and degradation rates
spleen_macrophage_ksyn_lyso_GL1_bulk           = theta(17) ;                     % [1/hr] synthesis rate 
spleen_macrophage_ksyn_lyso_GL1                = 38.39        ;                 %  [uM/hr] synthesis rate 
spleen_macrophage_kdeg_lyso_GL1_plasma         = log(2)/0.5   ;                 % [1/hr] degradation rate 

spleen_macrophage_kdeg_CER                     = theta(24); 
spleen_macrophage_KM_deg_CER                   = theta(25);
spleen_macrophage_k_CER_to_GL1                 = 666640 ;                       % [uM/hr]
spleen_macrophage_Km_CER_to_GL1                = 200 ;
spleen_macrophage_Km_lyso_GL1                  = 244.086      ;                 % [uM]

    parameters(9)              = spleen_macrophage_ksyn_lyso_GL1_bulk;
    parameters(10)              = spleen_macrophage_ksyn_lyso_GL1;    
    parameters(11)              = spleen_macrophage_kdeg_lyso_GL1_plasma;
    
    parameters(12)              = spleen_macrophage_kdeg_CER;
    parameters(13)              = spleen_macrophage_KM_deg_CER;
    parameters(14)              = spleen_macrophage_k_CER_to_GL1;
    parameters(15)              = spleen_macrophage_Km_CER_to_GL1;
    parameters(16)              = spleen_macrophage_Km_lyso_GL1;

% inclusion-related
spleen_macrophage_ktrans                       = 1/50 ;
spleen_macrophage_N_GL1_incl_crit              = 6e5 ;                          % [umol]
spleen_macrophage_h_func                       = 2   ;

    parameters(17)              = spleen_macrophage_ktrans; 
    parameters(18)              = spleen_macrophage_N_GL1_incl_crit;
    parameters(19)              = spleen_macrophage_h_func;
        
%% spleen volume model-related parameters

% growth term 
S_R_GD1_1                       = theta(19); 	

    parameters(20)              = S_R_GD1_1;
    
% repair terms
S_R_repair_1                    = theta(20) ;	
S_R_repair_2                    = theta(22) ; 	

    parameters(21)              = S_R_repair_1;
    parameters(22)              = S_R_repair_2;
    
% critical value for phi
S_phi_enhanced_crit             = theta(23) ; 	

    parameters(23)              = S_phi_enhanced_crit;
    
% volumes (multiples of normal)
S_V_spleen_max                  = theta(21) ;	
S_V_spleen_min                  = 1 ; 	

    parameters(24)              = S_V_spleen_max;
    parameters(25)              = S_V_spleen_min;  



%% adjustments to degradation and concentration parameters

Gaucher_par                     = theta(18);	 

spleen_macrophage_adj_GL1_deg   = Gaucher_par;

    parameters(34)              = spleen_macrophage_adj_GL1_deg; 
    
end
